import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.sql.*;

import javax.swing.*;

public class Password extends JFrame implements ActionListener
{		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JPasswordField pr,pl;
	JToolBar tb;
	JLabel ll1,ll2,ll3,ll5,ll6;
	JLabel lr1,lr2,lr3,lr4,lr5,lr6,lr7,lr8,lr9;
	JTextField tl;
	Connection con;
	Connectivity cc;
	JTextField tr1,tr2,tr3,tr4,tr5;
	JButton bl1,bl2,bl3,bl4;
	JButton tb1,tb2;
	JButton br1,br2;
	String str;
	int status;
	JComboBox<String> c;
	int count;
	JFrame current_frame;
	String str1,str2;
	int f=0,pass_attemp_admin=0,pass_attemp_stud=0;	
	public Password()
	{
		super("Library Management System");
		setSize(900,500);
		setBounds(450,150,400,500);
		setLayout(null);
		current_frame=this;
		setResizable(false);
		tb=new JToolBar();
		tb.setBounds(0, 0, 900, 30);
		add(tb);
		tb1=new JButton("Admin");
		tb.add(tb1);
		tb1.addActionListener(this);
		tb2=new JButton("Student");
		tb.add(tb2);
		tb2.addActionListener(this);		
		lr1=new JLabel("");
		lr1.setBounds(480,20, 400,50);
		lr1.setFont(new Font(getName(),Font.ITALIC,30));
		add(lr1);				
		ll1=new JLabel("Login Menu");
		ll1.setBounds(100,30, 300,50);
		ll1.setFont(new Font(getName(),Font.ITALIC,30));		
		add(ll1);
		ll5=new JLabel("**Admin");
		ll5.setBounds(50,80,300,40);
		ll5.setFont(new Font(getName(),Font.ITALIC,20));		
		add(ll5);		
		ll2=new JLabel("Username");
		ll2.setBounds(100,150,80,20);
		add(ll2);		
		ll3=new JLabel("Password");
		ll3.setBounds(100,200,80,20);
		add(ll3);
		tl=new JTextField();
		tl.setBounds(200,150,80,20);
		add(tl);
		tl.setEnabled(false);
		tl.addFocusListener(new FocusListener() {
			@Override
			public void focusLost(FocusEvent arg0){}
			@Override
			public void focusGained(FocusEvent arg0){
				tl.selectAll();
			}
		});
		pl=new JPasswordField();
		pl.setBounds(200,200,80,20);
		add(pl);
		pl.addFocusListener(new FocusListener() {
			@Override
			public void focusLost(FocusEvent arg0){}
			@Override
			public void focusGained(FocusEvent arg0){
				pl.selectAll();
			}
		});
		pl.setEnabled(false);
		ll6=new JLabel("Forget password");
		ll6.setForeground(Color.RED);
		ll6.setBounds(190,235,100,20);
		add(ll6);
		ll6.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e){}
			@Override
			public void mousePressed(MouseEvent e){
				if(status==1 || status==2)
				{
					ForgetPassword fp=new ForgetPassword(status,current_frame);
					fp.setVisible(true);
				}
			}
			@Override
			public void mouseExited(MouseEvent e){}
			@Override
			public void mouseEntered(MouseEvent e){}
			@Override
			public void mouseClicked(MouseEvent e){}
		});
		bl1=new JButton("Log In");
		bl1.setBounds(60,320,80,20);
		add(bl1);
		bl1.setEnabled(false);
		bl2=new JButton("Retry");
		bl2.setBounds(150,320,80,20);
		add(bl2);
		bl2.setEnabled(false);
		bl3=new JButton("Register");
		bl3.setBounds(150, 380, 100, 20);
		add(bl3);
		bl3.setEnabled(false);
		bl4=new JButton("Exit");
		bl4.setBounds(240,320,80,20);
		add(bl4);
		bl4.setEnabled(false);
		lr2=new JLabel("Name");
		lr2.setBounds(400, 100, 100, 20);
		add(lr2);
		lr3=new JLabel("Address");
		lr3.setBounds(400, 135, 100, 20);
		add(lr3);
		lr4=new JLabel("Phone no");
		lr4.setBounds(400, 170, 100, 20);
		add(lr4);
		lr5=new JLabel("UserName");
		lr5.setBounds(400, 205, 100, 20);
		add(lr5);
		lr6=new JLabel("PassWord");
		lr6.setBounds(400, 240, 100, 20);
		add(lr6);
		lr7=new JLabel("Select any one");
		lr7.setBounds(400, 300, 100, 20);
		add(lr7);
		lr8=new JLabel("Ans");
		lr8.setBounds(400, 335, 100, 20);
		add(lr8);
		tr1=new JTextField();
		tr1.setBounds(520, 100, 150, 20);
		add(tr1);
		tr1.setEnabled(false);		
		tr2=new JTextField();
		tr2.setBounds(520, 135, 150, 20);
		add(tr2);
		tr2.setEnabled(false);		
		tr3=new JTextField();
		tr3.setBounds(520, 170, 150, 20);
		add(tr3);
		tr3.setEnabled(false);		
		tr4=new JTextField();
		tr4.setBounds(520, 205, 150, 20);
		add(tr4);
		tr4.setEnabled(false);		
		pr=new JPasswordField();
		pr.setBounds(520, 240, 150, 20);
		add(pr);		
		pr.setEnabled(false);
		c=new JComboBox<String>();		
		c.setBounds(520, 300, 300, 20);
		add(c);
		tr5=new JTextField();
		tr5.setBounds(520, 335, 150, 20);
		add(tr5);
		tr5.setEnabled(false);		
		lr9=new JLabel("");
		lr9.setBounds(520, 270, 300, 20);
		add(lr9);
		br1=new JButton("Register");
		br1.setBounds(530, 420, 100, 20);
		add(br1);
		br1.setEnabled(false);
		br2=new JButton("Cancel");
		br2.setBounds(660, 420, 100, 20);
		add(br2);
		br2.setEnabled(false);
		bl1.addActionListener(this);
		bl2.addActionListener(this);
		bl3.addActionListener(this);
		bl4.addActionListener(this);
		br1.addActionListener(this);
		br2.addActionListener(this);
		c.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent arg0)
			{
				str=(String)c.getSelectedItem();
			}
		});
		addWindowListener(new WindowAdapter() { public void windowClosing(WindowEvent we){
			System.exit(0);
			}});				
		pr.addKeyListener(new KeyAdapter() {
		@SuppressWarnings("deprecation")
		public void keyTyped(KeyEvent ke)
		{
			lr9.setText("");			
			if(pr.getText().length()>6 && pr.getText().length()<20)
			{
				f=1;
				if(pr.getText().length()<12)
				{
					lr9.setText("Weak Password");
					lr9.setForeground(Color.pink);
				}
				else if(pr.getText().length()<16)
				{
					lr9.setText("Medium Password");
					lr9.setForeground(Color.yellow);
				}
				else
				{
					lr9.setText("Strong Password");
					lr9.setForeground(Color.green);
				}
			}
		}});				
	}
	@SuppressWarnings("deprecation")
	@Override
	public void actionPerformed(ActionEvent a)
	{
		Connectivity cc=null;
		Connection con=null;		
		int fa=0,fn=0,fs=0;
		int f1=-1;
		str1=tl.getText();
		str2=pl.getText();
		if(bl1==a.getSource())
		{
			if((tl.getText().length()==0) && (pl.getText().length()==0))
				JOptionPane.showMessageDialog(bl1, "Please fill username and password");
			else
			{				
				try
				{
					cc = new Connectivity();
				}
				catch (Exception ex)
				{					
					JOptionPane.showMessageDialog(bl1,"Database not Found");					
				}						
				con=cc.getConn();				
				if(status==1)
				{
					if(pass_attemp_admin<2)
					{
						try
						{
							PreparedStatement pstmt=con.prepareStatement("select * from librarien where un=? and pass=?");							
							pstmt.setString(1, tl.getText());
							pstmt.setString(2, pl.getText());
							ResultSet rs=pstmt.executeQuery();
							while(rs.next())
							{								
								f1=1;								
								PreparedStatement pstmt1=con.prepareStatement("insert into session values(?,?,?)");								
								pstmt1.setString(1,tl.getText());
								pstmt1.setString(2, pl.getText());
								pstmt1.setString(3,Inet4Address.getLocalHost().getHostAddress());
								pstmt1.executeUpdate();
								tl.setText("");
								pl.setText("");
								pass_attemp_admin=0;
								Menu m=new Menu(current_frame,status,str1,str2);
								m.setVisible(true);						
								dispose();
							}
						}
						catch(Exception e)
						{							
							e.printStackTrace();
						}
						if(f1!=1)
						{
							tl.setText("");
							pl.setText("");
							JOptionPane.showMessageDialog(bl1, "UserName or PassWord is incorrect");											
							pass_attemp_admin++;					
						}				
					}
					else
					{
						JOptionPane.showMessageDialog(bl1,"You do unsuccessful login more than 3 times");
						System.exit(0);
					}
				}
				else if(status==2)
				{
					if(pass_attemp_admin<2)
					{
						try
						{
							PreparedStatement pstmt=con.prepareStatement("select * from student where id=? and pass=?");
							pstmt.setString(1, tl.getText());
							pstmt.setString(2, pl.getText());
							ResultSet rs=pstmt.executeQuery();
							while(rs.next())
							{
								f1=1;
								tl.setText("");
								pl.setText("");						
								pass_attemp_admin=0;								
								Menu m=new Menu(current_frame,status,str1,str2);
								m.setVisible(true);						
								dispose();
							}
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
						if(f1!=1)
						{
							tl.setText("");
							pl.setText("");
							JOptionPane.showMessageDialog(bl1, "UserName or PassWord is Incorrect");
							pass_attemp_admin++;					
						}				
					}
					else
					{
						JOptionPane.showMessageDialog(bl1,"You do unsuccessful login more than 3 times");
						System.exit(0);
					}
				}
			}
		}		
		else if(bl2==a.getSource())
		{
			tl.setText("");
			pl.setText("");			
			tl.setEnabled(true);
			pl.setEnabled(true);
			bl1.setEnabled(true);
		}
		else if(bl3==a.getSource())
		{
			if(status==1)
			{
				for(int i=0;i<500;i+=5)
				{
					setBounds(450,150,400+i,500);
					try
					{
						Thread.sleep(10);
					}
					catch(InterruptedException e)
					{
						e.printStackTrace();
					}
				}
				c.addItem("What is your favourite Movie");
				c.addItem("What is your favourite TV chennel");
				c.addItem("What is your NickName");
				c.addItem("What is your favourite Book");
				c.addItem("What is your favourite song");
				lr1.setEnabled(true);
				tl.setText("");
				pl.setText("");				
				tl.setEnabled(false);
				pl.setEnabled(false);
				bl1.setEnabled(false);
				bl2.setEnabled(false);
				bl3.setEnabled(false);
				bl4.setEnabled(false);
				tr1.setEnabled(true);
				tr2.setEnabled(true);
				tr3.setEnabled(true);
				tr4.setEnabled(true);
				pr.setEnabled(true);
				tr5.setEnabled(true);
				br1.setEnabled(true);
				br2.setEnabled(true);
			}
			else
			{
				tl.setText("");
				pl.setText("");
				setEnabled(false);
				AddStudent as=new AddStudent(current_frame);
				as.setVisible(true);
			}
		}
		else if(bl4==a.getSource())
		{
			int result=JOptionPane.showConfirmDialog(bl4,"Choose Yes or NO","Exit",JOptionPane.YES_NO_OPTION);
			if(result == JOptionPane.YES_OPTION)
				System.exit(0);
			else if(result == JOptionPane.NO_OPTION)
			{
				current_frame.setVisible(true);				
			}
		}
		
		else if(br1==a.getSource())
		{
			try
			{
				cc = new Connectivity();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}
			con=cc.getConn();
			PreparedStatement pstmt1,pstmt2,pstmt3;
			try
			{
				pstmt1=con.prepareStatement("insert into librarien values(?,?,?,?,?,?,?)");
				pstmt2=con.prepareStatement("insert into backup_librarien values(?,?,?,?,?,?,?)");
				pstmt3=con.prepareStatement("insert into session values(?,?,?)");
				pstmt1.setString(1, tr1.getText());
				pstmt1.setString(2, tr2.getText());
				pstmt1.setString(3, tr3.getText());
				pstmt1.setString(4, tr4.getText());
				pstmt1.setString(5, pr.getText());
				pstmt1.setString(6, str);
				pstmt1.setString(7, tr5.getText());				
				pstmt2.setString(1, tr1.getText());
				pstmt2.setString(2, tr2.getText());
				pstmt2.setString(3, tr3.getText());
				pstmt2.setString(4, tr4.getText());
				pstmt2.setString(5, pr.getText());
				pstmt2.setString(6, str);
				pstmt2.setString(7, tr5.getText());
				pstmt3.setString(1, tr4.getText());
				pstmt3.setString(2, pr.getText());
				pstmt3.setString(3, (String)Inet4Address.getLocalHost().getHostAddress());
				if(pr.getText().length()>8 && pr.getText().length()<20)
				{
					for(int i=0;i<pr.getText().length();i++)
					{
						if(pr.getText().charAt(i)>'A' && pr.getText().charAt(i)<'Z')
						{
							fa=1;
							continue;
						}
						if(pr.getText().charAt(i)>'0' && pr.getText().charAt(i)<'9')
						{
							fn=1;
							continue;
						}
						if(!(pr.getText().charAt(i)>'0' && pr.getText().charAt(i)<'9') && !(pr.getText().charAt(i)>'A' && pr.getText().charAt(i)<'Z') && !(pr.getText().charAt(i)>'a' && pr.getText().charAt(i)<'z'))
						{
							fs=1;
							continue;
						}
					}
				}
				if((fa==1) && (fn==1) && (fs==1))
				{
					dispose();
					int res=JOptionPane.showConfirmDialog(br1,"Do you want to register","Registration",JOptionPane.YES_NO_OPTION);
					if(res==JOptionPane.YES_OPTION)
					{						
						pstmt1.executeUpdate();
						pstmt2.executeUpdate();
						pstmt3.executeUpdate();
						setBounds(450,150,400,500);
						tr1.setText("");
						tr2.setText("");
						tr3.setText("");
						tr4.setText("");
						pr.setText("");
						c.removeAllItems();
						tr5.setText("");
						Menu m=new Menu(current_frame,status,str1,str2);
						m.setVisible(true);
					}
					else
					{
						current_frame.setVisible(true);
					}
				}
				else if((fa==1) && (fn==1) && (fs==0))
				{
					JOptionPane.showMessageDialog(br1,"There should be atleast 1 Symbol");
					pr.setText("");
				}
				else if((fa==1) && (fn==0) && (fs==1))
				{
					JOptionPane.showMessageDialog(br1,"There should be atleast 1 Numeric");
					pr.setText("");
				}
				else if((fa==0) && (fn==1) && (fs==1))
				{
					JOptionPane.showMessageDialog(br1,"There should be atleast 1 Upper case");
					pr.setText("");
				}
				else if((fa==1) && (fn==0) && (fs==0))
				{
					JOptionPane.showMessageDialog(br1,"There should be atleast 1 Symbol & Numeric");
					pr.setText("");
				}
				else if((fa==0) && (fn==1) && (fs==0))
				{
					JOptionPane.showMessageDialog(br1,"There should be atleast 1 Symbol & Upper case");
					pr.setText("");
				}
				else if((fa==0) && (fn==0) && (fs==1))
				{
					JOptionPane.showMessageDialog(br1,"There should be atleast 1 Upper case & Numeric");
					pr.setText("");
				}
				else if((fa==0) && (fn==0) && (fs==0))
				{
					JOptionPane.showMessageDialog(br1,"There should be atleast 1 Symbol,Numeric,Upper case");
					pr.setText("");
				}				
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(br1,"This username and password is already exist");
				current_frame.setVisible(true);
			}
		}
		else if(br2==a.getSource())
		{
			tr1.setText("");
			tr2.setText("");
			tr3.setText("");
			tr4.setText("");
			pr.setText("");
			c.removeAllItems();
			tr5.setText("");
			for(int i=0;i<500;i+=5)
			{
				setBounds(450,150,900-i,500);
				try
				{
					Thread.sleep(15);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}			
			ll1.setEnabled(true);
			lr1.setEnabled(false);			
			ll2.setEnabled(true);
			ll3.setEnabled(true);
			tl.setEnabled(true);
			pl.setEnabled(true);
			bl1.setEnabled(true);
			bl2.setEnabled(true);
			bl3.setEnabled(true);
			bl4.setEnabled(true);
			tr1.setEnabled(false);
			tr2.setEnabled(false);
			tr3.setEnabled(false);
			tr4.setEnabled(false);
			pr.setEnabled(false);
			tr4.setEnabled(false);
			br1.setEnabled(false);
			br2.setEnabled(false);
			lr9.setText("");
		}
		else if(tb1==a.getSource())
		{
			status=1;
			ll5.setText("**Admin");
			lr1.setText("Registration (Admin)");
			tl.setEnabled(true);
			pl.setEnabled(true);
			bl1.setEnabled(true);
			bl2.setEnabled(true);
			bl3.setEnabled(true);
			bl4.setEnabled(true);
			try{
				cc=new Connectivity();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
			con=cc.getConn();
			try{
				PreparedStatement pstmt1=con.prepareStatement("select * from session where ip=?");
				try{
					pstmt1.setString(1,Inet4Address.getLocalHost().getHostAddress());
				}
				catch(UnknownHostException e)
				{
					e.printStackTrace();
				}
				ResultSet rs=pstmt1.executeQuery();
				while(rs.next())
				{
					Menu m=new Menu(this, status,rs.getString("id"),rs.getString("pass"));
					m.setVisible(true);
					dispose();
				}
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		else if(tb2==a.getSource())
		{
			status=2;
			ll5.setText("**Student");
			lr1.setText("Registration (Student)");
			tl.setEnabled(true);
			pl.setEnabled(true);
			bl1.setEnabled(true);
			bl2.setEnabled(true);
			bl3.setEnabled(true);
			bl4.setEnabled(true);			
		}
	}		
	public static void main(String arr[])
	{
		Password p=new Password();
		p.setVisible(true);
	}	
}