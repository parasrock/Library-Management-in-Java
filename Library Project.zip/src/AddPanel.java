import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.sql.*;
import java.util.Calendar;
import java.util.TreeSet;

import javax.swing.*;

public class AddPanel extends JPanel implements ActionListener,Runnable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JToolBar toolbar;
	JLabel label1,label2,label3,label4,label5,label6,label7,label8,label9,label10,title;
	JTextField textfield1,textfield2,textfield3,textfield4,textfield5,textfield6;
	JButton add,showtoolbutton,searchtoolbutton,deletetoolbutton,issuetoolbutton,returntoolbutton,clear,bb7;
	JFrame add_frame,menu_frame,pass_frame;
	int f=0,x=0,check;
	JComboBox<String> c;
	Connection con;
	String s="";
	Connectivity cc;
	TreeSet<String> ts;
	JPanel current_panel;
	String id,pass;
	Thread thread1,thread2,thread;
	Calendar calender;
	public AddPanel(final JFrame add_frame,final JFrame menu_frame,final JFrame pass_frame,final String id,final String pass)
	{
		setLayout(null);
		this.add_frame=add_frame;
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;
		current_panel=this;
		thread1=new Thread(this);
		title=new JLabel("ADD MENU");
		title.setFont(new Font(getName(),Font.LAYOUT_RIGHT_TO_LEFT,30));
		title.setBounds(50, 70, 300, 40);
		add(title);
		label9=new JLabel("");
		label9.setBounds(getToolkit().getScreenSize().width-180,50,100,30);
		label9.setFont(new Font(getName(), Font.BOLD, 20));		
		add(label9);
		this.id=id;
		this.pass=pass;
		label8=new JLabel("ADD BOOKS");
		label8.setFont(new Font(getName(),Font.ITALIC,30));
		label8.setBounds(200, 70, 300, 50);
		label8.setForeground(Color.BLUE);
		label1=new JLabel("Book ID");		
		label1.setBounds(450,180, 150, 20);
		add(label1);
		textfield1=new JTextField();
		textfield1.setBounds(650,180, 150, 20);
		add(textfield1);
		label2=new JLabel("Book Name");
		label2.setBounds(450,220, 150, 20);
		add(label2);
		textfield2=new JTextField();
		textfield2.setBounds(650,220, 150, 20);
		add(textfield2);
		label3=new JLabel("Author Name");
		label3.setBounds(450, 260, 150, 20);
		add(label3);
		textfield3=new JTextField();
		textfield3.setBounds(650, 260, 150, 20);
		add(textfield3);
		label10=new JLabel("Category");
		label10.setBounds(450, 300, 150, 20);
		add(label10);
		ts=new TreeSet<String>();
		c=new JComboBox<String>();
		c.setBounds(650, 300, 150, 20);
		add(c);
		c.setEditable(true);
		label4=new JLabel("Sale price");
		label4.setBounds(450, 340, 150, 20);
		add(label4);
		textfield4=new JTextField();		
		textfield4.setBounds(650, 340, 150, 20);
		add(textfield4);
		label5=new JLabel("Purchase Price");
		label5.setBounds(450, 380, 150, 20);
		add(label5);
		textfield5=new JTextField();
		textfield5.setBounds(650, 380, 150, 20);
		add(textfield5);
		label6=new JLabel("Quantity");
		label6.setBounds(450, 420, 150, 20);
		add(label6);
		textfield6=new JTextField();
		textfield6.setBounds(650,420, 150, 20);
		add(textfield6);
		add=new JButton("Add Book");
		add.setBounds(600, 540, 110, 20);
		add.addActionListener(this);
		add(add);		
		label7=new JLabel(new ImageIcon("back.jpg"));
		label7.setBounds(getToolkit().getScreenSize().width-100,45, 50, 40);
		add(label7);
		label7.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent arg0) {}
			@Override
			public void mousePressed(MouseEvent arg0) {}
			@Override
			public void mouseExited(MouseEvent arg0) {}
			@Override
			public void mouseEntered(MouseEvent arg0) {}
			@Override
			public void mouseClicked(MouseEvent arg0)
			{
				textfield1.setText("");
				textfield2.setText("");
				textfield3.setText("");
				textfield4.setText("");
				textfield5.setText("");
				textfield6.setText("");						
				menu_frame.setVisible(true);
				add_frame.dispose();
			}
		});		
		c.getEditor().setItem((String)"");
		PanelAuthorName.s="";		
		((JTextField)c.getEditor().getEditorComponent()).addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent arg0){}
			@Override
			public void keyReleased(KeyEvent arg0){}
			@Override
			public void keyPressed(KeyEvent arg0) {								
				try
				{
					cc=new Connectivity();
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
				con=cc.getConn();				
				try
				{										
					PreparedStatement pstmt=con.prepareStatement("select * from book where cat like '"+((JTextField)c.getEditor().getEditorComponent()).getText()+arg0.getKeyChar()+"%'");
					ResultSet rs=pstmt.executeQuery();			
					c.removeAllItems();
					ts.clear();
					while(rs.next())
						ts.add(rs.getString("cat"));
					for(String str:ts)
						c.addItem(str);
					((JTextField)c.getEditor().getEditorComponent()).setText(s);
					if((arg0.getKeyChar()>='a' && arg0.getKeyChar()<='z') || (arg0.getKeyChar()>='A' && arg0.getKeyChar()<='Z') || (arg0.getKeyChar()>='0' && arg0.getKeyChar()<='9'))
						s=s+(arg0.getKeyChar());
					if(arg0.getKeyChar()==KeyEvent.VK_BACK_SPACE)
						if(s.length()!=0)
							s=s.substring(0,s.length()-1);
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
		});		
		toolbar=new JToolBar();
		toolbar.setBounds(0,0,getToolkit().getScreenSize().width,40);
		add(toolbar);
		showtoolbutton=new JButton(new ImageIcon("view.jpg"));
		showtoolbutton.setToolTipText("Show Books");
		showtoolbutton.addActionListener(this);
		toolbar.add(showtoolbutton);
		searchtoolbutton=new JButton(new ImageIcon("search.jpg"));
		searchtoolbutton.setToolTipText("Search Books");
		searchtoolbutton.addActionListener(this);
		toolbar.add(searchtoolbutton);
		deletetoolbutton=new JButton(new ImageIcon("delete.jpg"));
		deletetoolbutton.setToolTipText("Delete Books");
		deletetoolbutton.addActionListener(this);
		toolbar.add(deletetoolbutton);
		issuetoolbutton=new JButton(new ImageIcon("issuebook.jpg"));
		issuetoolbutton.setToolTipText("Issue Menu");
		issuetoolbutton.addActionListener(this);
		toolbar.add(issuetoolbutton);		
		returntoolbutton=new JButton(new ImageIcon("returnBook.jpg"));
		returntoolbutton.setToolTipText("Return Books");
		returntoolbutton.addActionListener(this);
		toolbar.add(returntoolbutton);
		bb7=new JButton("Warning");
		toolbar.add(bb7);
		bb7.addActionListener(this);			
		textfield1.addFocusListener(new FocusListener() {
			@Override
			public void focusLost(FocusEvent arg0)
			{
				Connectivity cc=null;
				Connection con=null;
				try
				{
					cc = new Connectivity();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}						
				con=cc.getConn();
				if(textfield1.getText().length()!=0)
				{
						f=0;
						PreparedStatement pstmt1;
						try
						{						
							pstmt1=con.prepareStatement("select * from book where id=?");
							try
							{
								pstmt1.setInt(1,Integer.parseInt(textfield1.getText()));
								ResultSet rs=pstmt1.executeQuery();
								while(rs.next())
								{
									textfield2.setText(rs.getString("bn"));							
									textfield3.setText(rs.getString("an"));							
									c.setSelectedItem(rs.getString("cat"));							
									textfield4.setText(String.valueOf(rs.getInt("sp")));							
									textfield5.setText(String.valueOf(rs.getInt("pp")));							
									c.setSelectedItem(rs.getString("cat"));
									f=1;							
									x=rs.getInt("q");
								}
							}
							catch(NumberFormatException nf)
							{						
								JOptionPane.showMessageDialog(add, "Please insert a Integer value");
								textfield1.setText("");
							}							
						}
						catch(SQLException sqle)
						{
							sqle.printStackTrace();
						}
				}
				current_panel.setFocusable(true);
			}
			@Override
			public void focusGained(FocusEvent arg0) {				
				textfield2.setText("");				
				textfield3.setText("");				
				c.removeAllItems();
				textfield4.setText("");
				textfield5.setText("");
			}
		});
		thread1.start();
		thread2=new Thread(this);
		setFocusable(true);
		addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent arg0) {
			}
			@Override
			public void keyReleased(KeyEvent arg0) {
			}
			@Override
			public void keyPressed(KeyEvent arg0) {
				if(KeyEvent.VK_ESCAPE==arg0.getKeyChar())
				{
					thread2.start();
				}
			}
		});
		thread=new Thread(this);
		thread.start();
	}
	@Override
	public void actionPerformed(ActionEvent a)
	{
		Connection con=null;
		Connectivity cc=null;
		int ff=0;		
		if(add==a.getSource())
		{			
			try
			{
				cc = new Connectivity();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}
			con=cc.getConn();
			try
			{
				x=x+(Integer.parseInt(textfield6.getText()));			
				if(f==1)
				{
					try
					{
						int x2=0;
						PreparedStatement pstmt=con.prepareStatement("update book set q=? where id=?");					
						pstmt.setInt(1,x);
						pstmt.setInt(2,Integer.parseInt(textfield1.getText()));
						x2=Integer.parseInt(textfield6.getText());
						int x1=JOptionPane.showConfirmDialog(add,"Update Record  ??","Add",JOptionPane.YES_NO_OPTION);
						if(x1==JOptionPane.YES_OPTION)
						{
							pstmt.executeUpdate();						
							JOptionPane.showConfirmDialog(add,x2+" Books Updated","Message",JOptionPane.PLAIN_MESSAGE);
							textfield1.setText("");
							textfield2.setText("");
							textfield3.setText("");
							textfield4.setText("");
							textfield5.setText("");
							textfield6.setText("");
						}					
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
				}
				else if(f==0)
				{					
					try
					{
						int x2=0;
						PreparedStatement pstmt=con.prepareStatement("insert into book values(?,?,?,?,?,?,?)");
						try{
							pstmt.setInt(1,Integer.parseInt(textfield1.getText()));
							try{
								pstmt.setString(2, textfield2.getText());
								try{
									pstmt.setString(3, textfield3.getText());
									try{
										pstmt.setInt(4, Integer.parseInt(textfield4.getText()));
										try{
											pstmt.setInt(5, Integer.parseInt(textfield5.getText()));
											try{
												pstmt.setInt(6, Integer.parseInt(textfield6.getText()));												
												pstmt.setString(7,((JTextField)c.getEditor().getEditorComponent()).getText());
												x2=Integer.parseInt(textfield6.getText());
												int x1=JOptionPane.showConfirmDialog(add,"Add Record  ??","Add",JOptionPane.YES_NO_OPTION);
												if(x1==JOptionPane.YES_OPTION)
												{
													pstmt.executeUpdate();
													JOptionPane.showConfirmDialog(add,x2+" Books Added","Message",JOptionPane.PLAIN_MESSAGE);
													c.removeAllItems();
													s="";
													textfield1.setText("");
													textfield2.setText("");
													textfield3.setText("");
													textfield4.setText("");
													textfield5.setText("");
													textfield6.setText("");
												}
											}
											catch(NumberFormatException nfe)
											{
												ff=1;
												textfield6.setText("");
											}
										}
										catch(NumberFormatException nfe)
										{
											ff=1;
											textfield5.setText("");
										}
									}
									catch(NumberFormatException nfe)
									{
										ff=1;
										textfield4.setText("");
									}
								}
								catch(NumberFormatException nfe)
								{
									ff=1;
									textfield3.setText("");
								}
							}
							catch(NumberFormatException nfe)
							{
								ff=1;
								textfield2.setText("");
							}						
						}
						catch(NumberFormatException nfe)
						{
							ff=1;
							textfield1.setText("");
						}
					}
					catch(SQLException sqle)
					{	
						sqle.printStackTrace();
					}					
				}
			}
			catch(NumberFormatException nfe)
			{
				ff=1;
			}
			if(ff==1)
				JOptionPane.showMessageDialog(add, "Please Enter input in Correct type");
			setFocusable(true);
		}
		else if(showtoolbutton==a.getSource())
		{
			textfield1.setText("");
			textfield2.setText("");
			textfield3.setText("");
			textfield4.setText("");
			textfield5.setText("");
			textfield6.setText("");
			ShowMenu am=new ShowMenu(menu_frame,pass_frame,1,id,pass);
			am.setVisible(true);
			add_frame.dispose();
		}
		else if(searchtoolbutton==a.getSource())
		{
			textfield1.setText("");
			textfield2.setText("");
			textfield3.setText("");
			textfield4.setText("");
			textfield5.setText("");
			textfield6.setText("");
			SearchMenu sm=new SearchMenu(menu_frame,pass_frame,1,id,pass);
			sm.setVisible(true);
			add_frame.dispose();
		}
		else if(deletetoolbutton==a.getSource())
		{
			textfield1.setText("");
			textfield2.setText("");
			textfield3.setText("");
			textfield4.setText("");
			textfield5.setText("");
			textfield6.setText("");
			DeleteMenu dm=new DeleteMenu(menu_frame,pass_frame,id,pass);
			dm.setVisible(true);
			add_frame.dispose();
		}				
		else if(issuetoolbutton==a.getSource())
		{
			textfield1.setText("");
			textfield2.setText("");
			textfield3.setText("");
			textfield4.setText("");
			textfield5.setText("");
			textfield6.setText("");
			IssueMenu im=new IssueMenu(menu_frame,pass_frame,id,pass);
			im.setVisible(true);
			add_frame.dispose();
		}
		else if(returntoolbutton==a.getSource())
		{
			textfield1.setText("");
			textfield2.setText("");
			textfield3.setText("");
			textfield4.setText("");
			textfield5.setText("");
			textfield6.setText("");
			ReturnMenu im=new ReturnMenu(menu_frame,pass_frame,id,pass);
			im.setVisible(true);
			add_frame.dispose();
		}
		else if(bb7==a.getSource())
		{
			textfield1.setText("");
			textfield2.setText("");
			textfield3.setText("");
			textfield4.setText("");
			textfield5.setText("");
			textfield6.setText("");
			Warning w=new Warning(menu_frame, pass_frame, id, pass);
			w.setVisible(true);
			add_frame.dispose();
		}
	}
	@Override
	public void run()
	{
		while(Thread.currentThread()==thread1)
		{
			calender=Calendar.getInstance();
			label9.setText(calender.get(Calendar.HOUR)+":"+calender.get(Calendar.MINUTE)+":"+calender.get(Calendar.SECOND));
			try
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		if(Thread.currentThread()==thread2)
		{
			menu_frame.setVisible(true);
			add_frame.dispose();
		}
		if(Thread.currentThread()==thread)
		{
			try
			{
				cc=new Connectivity();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			con=cc.getConn();
			check=0;
			try
			{				
				PreparedStatement pstmt=con.prepareStatement("select * from book where q < 10");
				ResultSet rs=pstmt.executeQuery();
				while(rs.next())
				{
					bb7.setForeground(Color.RED);
					check=1;
				}
				if(check==0)
					bb7.setEnabled(false);
				else
					bb7.setEnabled(true);
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
	}	
}