import java.awt.Font;
import java.awt.event.*;
import java.io.IOException;
import java.sql.*;
import javax.swing.*;

public class LibrarienDetails extends JFrame implements ActionListener,FocusListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel l1,l2,l3,l4,l5,l6,l7,l;
	JTextField t1,t2,t3,t4,t7;
	JPasswordField p5;
	JComboBox<String> c6;
	JButton b1,b2,b3;
	JFrame current_frame;
	String str,str1;
	Connectivity cc=null;
	Connection con=null;
	public LibrarienDetails(final JFrame current_frame,String str,String str1)
	{
		setSize(500,420);
		setLayout(null);
		this.current_frame=current_frame;
		this.str=str;
		this.str1=str1;
		l=new JLabel("Librarien Details");
		l.setFont(new Font(getName(),Font.BOLD,30));
		l.setBounds(30, 20, 300, 40);
		add(l);
		l1=new JLabel("Name");
		l1.setBounds(70,100, 100, 20);
		add(l1);
		t1=new JTextField();		
		t1.setBounds(250,100, 150, 20);
		add(t1);
		t1.addFocusListener(this);
		t1.setEnabled(false);
		l2=new JLabel("Address");
		l2.setBounds(70,130, 100, 20);
		add(l2);
		t2=new JTextField();
		t2.setBounds(250,130, 150, 20);
		add(t2);
		t2.addFocusListener(this);
		t2.setEnabled(false);
		l3=new JLabel("Phone no");
		l3.setBounds(70,160, 100, 20);
		add(l3);
		t3=new JTextField();
		t3.setBounds(250,160, 150, 20);
		add(t3);
		t3.addFocusListener(this);
		t3.setEnabled(false);
		l4=new JLabel("Username");
		l4.setBounds(70,190, 100, 20);
		add(l4);
		t4=new JTextField();
		t4.setBounds(250,190, 150, 20);
		add(t4);
		t4.addFocusListener(this);
		t4.setEnabled(false);
		l5=new JLabel("Password");
		l5.setBounds(70,220, 100, 20);
		add(l5);
		p5=new JPasswordField();
		p5.setBounds(250,220, 150, 20);
		add(p5);
		p5.addFocusListener(this);
		p5.setEnabled(false);
		l6=new JLabel("Recovery_ques");
		l6.setBounds(70,250, 150, 20);
		add(l6);
		c6=new JComboBox<String>();
		c6.setBounds(250,250, 150, 20);
		add(c6);		
		c6.addItem("What is your favourite Movie");
		c6.addItem("What is your favourite TV chennel");
		c6.addItem("What is your NickName");
		c6.addItem("What is your favourite Book");
		c6.addItem("What is your favourite song");
		c6.setEnabled(false);
		l7=new JLabel("Ans of qus");
		l7.setBounds(70, 280, 100, 20);
		add(l7);
		t7=new JTextField();
		t7.setBounds(250, 280, 150, 20);
		add(t7);
		t7.addFocusListener(this);
		t7.setEnabled(false);
		b1=new JButton("Edit");
		b1.setBounds(40, 330, 100, 20);
		add(b1);
		b2=new JButton("Update");
		b2.setBounds(170, 330, 100, 20);
		add(b2);
		b2.setEnabled(false);
		b3=new JButton("Cancel");
		b3.setBounds(300, 330, 100, 20);
		add(b3);
		try
		{
			cc=new Connectivity();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		con=cc.getConn();
		try
		{
			PreparedStatement pstmt=con.prepareStatement("select * from librarien where un=? and pass=?");
			pstmt.setString(1, str);
			pstmt.setString(2, str1);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next())
			{
				t1.setText(rs.getString("name"));
				t2.setText(rs.getString("add"));
				t3.setText(rs.getString("pn"));
				t4.setText(rs.getString("un"));
				p5.setText(rs.getString("pass"));
				c6.setSelectedItem((rs.getString("qus")));
				t7.setText(rs.getString("ans"));
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		addWindowListener(new WindowAdapter() { public void windowClosing(WindowEvent e){ dispose(); current_frame.setEnabled(true); } });
	}
	@Override
	public void actionPerformed(ActionEvent a)
	{				
		if(b1==a.getSource())
		{			
			t1.setEnabled(true);
			t2.setEnabled(true);
			t3.setEnabled(true);
			c6.setEnabled(true);
			t7.setEnabled(true);
			b2.setEnabled(true);
		}
		else if(b2==a.getSource())
		{
			try
			{
				cc=new Connectivity();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
			con=cc.getConn();
			try
			{
				PreparedStatement pstmt=con.prepareStatement("update `librarien` set `name`=?,`add`=?,`pn`=?,`un`=?,`pass`=?,`qus`=?,`ans`=? where `un`=? and `pass`=?");
				pstmt.setString(1, t1.getText());
				pstmt.setString(2, t2.getText());
				pstmt.setString(3, t3.getText());
				pstmt.setString(4, str);
				pstmt.setString(5, str1);
				pstmt.setString(6, (String)c6.getSelectedItem());
				pstmt.setString(7, t7.getText());
				pstmt.setString(8, str);
				pstmt.setString(9, str1);
				int res=JOptionPane.showConfirmDialog(b2,"Do you want to Update your details","Update",JOptionPane.YES_NO_OPTION);
				if(res==JOptionPane.YES_OPTION)
				{
					pstmt.executeUpdate();
					t1.setEnabled(false);
					t2.setEnabled(false);
					t3.setEnabled(false);
					t4.setEnabled(false);
					p5.setEnabled(false);
					c6.setEnabled(false);
					t7.setEnabled(false);					
				}								
			}
			catch(SQLException e)
			{
				JOptionPane.showMessageDialog(b2,"This user is already has a ID");
			}
		}
		else if(b3==a.getSource())
		{
			dispose();
			current_frame.setEnabled(true);
		}
	}
	@Override
	public void focusGained(FocusEvent a)
	{
		if(t1==a.getSource())
		{
			t1.selectAll();
		}
		else if(t2==a.getSource())
		{
			t2.selectAll();
		}
		else if(t3==a.getSource())
		{
			t3.selectAll();
		}
		else if(t7==a.getSource())
		{
			t7.selectAll();
		}
	}
	@Override
	public void focusLost(FocusEvent a){}
}