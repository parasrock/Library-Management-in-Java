import java.io.*;
import java.sql.*;
public class Connectivity
{
	public Connectivity() throws IOException
    {
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
            }
            catch(ClassNotFoundException cnfe)
            {         
                System.exit(1);
            }	                                                 
    }

		public Connection getConn()
		{			
			Connection conn=null;
	        String connectionUrl = "jdbc:mysql://" + "localhost:3306" +  "/" + "lms";            
	    	try
	        {
	            conn=DriverManager.getConnection(connectionUrl,"root","rock");        
	        }
	        catch (SQLException sqle)
	        {
	               sqle.printStackTrace();
	               System.exit(1);
	        }
	    	return conn;
		}
}