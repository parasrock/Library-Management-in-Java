import java.awt.event.*;
import java.io.IOException;
import java.net.Inet4Address;
import java.sql.*;

import javax.swing.*;

public class ReturnMenu extends JFrame implements ActionListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JMenuBar menubar;
	JMenu menu1,menu2,menu3,menu4;
	JMenuItem m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11;
	JFrame current_frame,menu_frame,pass_frame;
	Connectivity cc;
	Connection con;
	String str,str1;
	public ReturnMenu(final JFrame menu_frame,final JFrame pass_frame,String str,String str1)
	{
		super("Library ManageMant System");
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setLayout(null);
		current_frame=this;
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;
		this.str=str;
		this.str1=str1;
		menubar=new JMenuBar();
		menu1=new JMenu("Books");
		menu2=new JMenu("Students");
		menu3=new JMenu("ID");
		menu4=new JMenu("Others");
		setJMenuBar(menubar);
		menubar.add(menu1);
		menubar.add(menu2);
		menubar.add(menu3);
		menubar.add(menu4);
		m1=new JMenuItem("Add Books");
		menu1.add(m1);		
		m1.addActionListener(this);
		menu1.addSeparator();
		m2=new JMenuItem("Show Books");
		menu1.add(m2);
		m2.addActionListener(this);
		menu1.addSeparator();
		m3=new JMenuItem("Search Books");
		menu1.add(m3);
		m3.addActionListener(this);
		menu1.addSeparator();
		m4=new JMenuItem("Delete Book");
		menu1.add(m4);
		m4.addActionListener(this);
		m5=new JMenuItem("Issue Books");
		menu2.add(m5);		
		m5.addActionListener(this);
		menu2.addSeparator();
		m6=new JMenuItem("Return Books");
		menu2.add(m6);
		m6.setEnabled(false);
		m11=new JMenuItem("View Details");		
		menu3.add(m11);
		m11.addActionListener(this);
		menu3.addSeparator();
		m7=new JMenuItem("Change Password");
		menu3.add(m7);
		m7.addActionListener(this);
		menu3.addSeparator();
		m8=new JMenuItem("Log out");
		menu3.add(m8);
		m8.addActionListener(this);
		m9=new JMenuItem("Help");
		menu4.add(m9);
		m9.addActionListener(this);
		menu4.addSeparator();
		m10=new JMenuItem("Exit");		
		menu4.add(m10);
		m10.addActionListener(this);
		ReturnPanel rp=new ReturnPanel(current_frame,menu_frame,pass_frame,str,str1);
		add(rp);
		rp.setBounds(0, 3, getToolkit().getScreenSize().width,getToolkit().getScreenSize().height);
		addWindowListener(new WindowAdapter() { public void windowClosing(WindowEvent we){			
				System.exit(0);			
		} });
	}
	@Override
	public void actionPerformed(ActionEvent a) 
	{
		if(m1==a.getSource())
		{
			AddMenu am=new AddMenu(menu_frame,pass_frame,str,str1);
			am.setVisible(true);
			dispose();
		}
		else if(m2==a.getSource())
		{
			ShowMenu am=new ShowMenu(menu_frame,pass_frame,1,str,str1);
			am.setVisible(true);
			dispose();
		}
		else if(m3==a.getSource())
		{
			SearchMenu am=new SearchMenu(menu_frame,pass_frame,1,str,str1);
			am.setVisible(true);
			dispose();
		}
		else if(m4==a.getSource())
		{
			DeleteMenu im=new DeleteMenu(menu_frame,pass_frame,str,str1);
			im.setVisible(true);
			dispose();
		}		
		else if(m5==a.getSource())
		{
			IssueMenu im=new IssueMenu(menu_frame,pass_frame,str,str1);
			im.setVisible(true);
			dispose();
		}
		else if(m7==a.getSource())
		{
			ChangePassword cp=new ChangePassword(current_frame,1,str);
			cp.setVisible(true);
		}
		else if(m8==a.getSource())
		{
			try{
				cc=new Connectivity();
			}
			catch(IOException e){
				e.printStackTrace();
			}
			con=cc.getConn();
			try{
				PreparedStatement pstmt=con.prepareStatement("delete from session where ip=?");
				pstmt.setString(1,Inet4Address.getLocalHost().getHostAddress());
				pstmt.executeUpdate();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			pass_frame.setVisible(true);
			dispose();
		}
		else if(m9==a.getSource())
		{
		}
		else if(m10==a.getSource())
		{
			int result=JOptionPane.showConfirmDialog(m10,"Choose Yes or NO","Exit",JOptionPane.YES_NO_OPTION);
			dispose();
			if(result == JOptionPane.YES_OPTION)
				System.exit(0);
			else
				current_frame.setVisible(true);
		}
		else if(m11==a.getSource())
		{
			LibrarienDetails ld=new LibrarienDetails(this, str, str1);
			ld.setVisible(true);
		}
	}
}