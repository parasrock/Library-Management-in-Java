import java.awt.Font;
import java.awt.event.*;
import java.sql.*;

import javax.swing.*;

public class StudentDetails extends JFrame implements ActionListener,FocusListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel l1,l2,l3,l4,l5,l6,l,l7,l8,l9,l10,l11,l12,l13;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
	JPasswordField p;
	JComboBox<String> c;
	JButton b1,b2,b3,b4;
	int pp,f,x;
	JFrame current_frame,last_frame;
	Connectivity cc=null;
	Connection con=null;
	String str,str1,str2,str3;
	public StudentDetails(final JFrame last_frame,String str,String str1)
	{		
		setLayout(null);
		this.str=str;
		this.str1=str1;
		setBounds(300,90,900,450);				
		l=new JLabel("Add Student");
		this.last_frame=last_frame;
		current_frame=this;
		l.setFont(new Font(getName(),Font.ITALIC,20));
		l.setBounds(30, 10, 300, 30);
		add(l);
		l1=new JLabel("Student ID");
		l1.setBounds(50,50, 150, 20);
		add(l1);
		t1=new JTextField();
		t1.setBounds(220,50, 150, 20);
		add(t1);
		t1.setEnabled(false);
		l2=new JLabel("Student Name");
		l2.setBounds(50,90, 150, 20);
		add(l2);
		t2=new JTextField();
		t2.setBounds(220,90, 150, 20);
		add(t2);
		t2.addFocusListener(this);
		t2.setEnabled(false);
		l3=new JLabel("Section");
		l3.setBounds(500, 90, 150, 20);
		add(l3);
		t3=new JTextField();
		t3.setBounds(620, 90, 150, 20);
		add(t3);
		t3.setEnabled(false);
		t3.addFocusListener(this);
		l4=new JLabel("Branch");
		l4.setBounds(50, 130, 150, 20);
		add(l4);
		t4=new JTextField();		
		t4.setBounds(220, 130, 150, 20);
		add(t4);
		t4.setEnabled(false);
		t4.addFocusListener(this);		
		l6=new JLabel("Phone no");
		l6.setBounds(500, 130, 150, 20);
		add(l6);
		t6=new JTextField();
		t6.setBounds(620, 130, 150, 20);
		add(t6);
		t6.addFocusListener(this);
		t6.setEnabled(false);
		l7=new JLabel("Address");
		l7.setBounds(50, 170, 150, 20);
		add(l7);
		t7=new JTextField();
		t7.setBounds(220, 170, 150, 20);
		add(t7);
		t7.addFocusListener(this);
		t7.setEnabled(false);
		l8=new JLabel("Password");
		l8.setBounds(500, 170, 150, 20);
		add(l8);
		p=new JPasswordField();
		p.setBounds(620, 170, 150, 20);
		add(p);
		p.setEnabled(false);
		l9=new JLabel("Issued books");
		l9.setBounds(50, 210, 150, 20);
		add(l9);
		t8=new JTextField();
		t8.setBounds(220, 210, 150, 20);
		add(t8);
		t8.addFocusListener(this);
		t8.setEnabled(false);
		l10=new JLabel("Choose any question");
		l10.setBounds(50, 250, 200, 20);
		add(l10);
		c=new JComboBox<String>();
		c.setBounds(220, 250, 220, 20);
		add(c);			
		c.setEnabled(false);
		l12=new JLabel("Answer");
		l12.setBounds(500, 250, 150, 20);
		add(l12);
		t9=new JTextField();
		t9.setBounds(620, 250, 150, 20);
		add(t9);
		t9.addFocusListener(this);
		t9.setEnabled(false);
		l13=new JLabel("Fine till now");
		l13.setBounds(50, 290, 200, 20);
		add(l13);
		t10=new JTextField();
		t10.setBounds(220,290,150,20);
		t10.setEnabled(false);
		add(t10);
		b1=new JButton("Edit");
		b1.setBounds(50, 350, 100, 25);
		add(b1);
		b2=new JButton("Update");
		b2.setBounds(250, 350, 100, 25);
		add(b2);
		b2.setEnabled(false);
		b4=new JButton("View All issued books");
		b4.setBounds(480,350,200,20);
		add(b4);		
		b3=new JButton("Cancel");
		b3.setBounds(750,350, 100, 25);
		add(b3);
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		c.addItem("What is your favourite Movie");
		c.addItem("What is your favourite TV chennel");
		c.addItem("What is your NickName");
		c.addItem("What is your favourite Book");
		c.addItem("What is your favourite song");
		try
		{
			cc=new Connectivity();
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		con=cc.getConn();						
		try
		{			
			PreparedStatement pstmt1=con.prepareStatement("select * from student where id=? and pass=?");
			pstmt1.setString(1, str);
			pstmt1.setString(2, str1);
			ResultSet rs=pstmt1.executeQuery();
			while(rs.next())
			{
				str2=rs.getString("id");
				t1.setText(rs.getString("id"));
				t2.setText(rs.getString("name"));
				t3.setText(rs.getString("section"));
				t4.setText(rs.getString("branch"));
				t8.setText(String.valueOf(rs.getInt("ib")));
				p.setText(rs.getString("pass"));
				c.setSelectedItem((rs.getString("qus")));
				t9.setText(rs.getString("ans"));
				t6.setText(rs.getString("pn"));
				t7.setText(rs.getString("add"));
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();				
		}
		try
		{
			x=0;
			int y=0;			
			PreparedStatement pstmt=con.prepareStatement("select DATEDIFF(issued_date,CURDATE()) from transaction where sid=? and return_date=?");
			pstmt.setString(1,str2);
			pstmt.setString(2,"");
			ResultSet rs=pstmt.executeQuery();
			while(rs.next())
			{
				y=rs.getInt(1);
				if(y>15)
					x=x+((Integer.parseInt(rs.getString("book_issued")))*y);
				else
					x=0;
			}
			t10.setText(String.valueOf(x));
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		addWindowListener(new WindowAdapter() { public void windowClosing(WindowEvent we)
		{
			dispose();
			last_frame.setEnabled(true);
		}
		});
	}

	@Override
	public void actionPerformed(ActionEvent a) 
	{
		if(b1==a.getSource())
		{
			t2.setEnabled(true);
			t3.setEnabled(true);
			t4.setEnabled(true);
			t6.setEnabled(true);
			t7.setEnabled(true);
			t9.setEnabled(true);
			c.setEnabled(true);
			b2.setEnabled(true);
			b1.setEnabled(false);
		}
		else if(b2==a.getSource())
		{
			try
			{
				PreparedStatement pstmt=con.prepareStatement("update `student` set `name`=?,`section`=?,`branch`=?,`pn`=?,`qus`=?,`ans`=?,`add`=? where `id`=?");				
				pstmt.setString(1,t2.getText());
				pstmt.setString(2,t3.getText());
				pstmt.setString(3,t4.getText());
				pstmt.setString(4,t6.getText());										
				pstmt.setString(5,(String)c.getSelectedItem());
				pstmt.setString(6,t9.getText());
				pstmt.setString(7,t7.getText());
				pstmt.setString(8,str);				
								
				int res=JOptionPane.showConfirmDialog(b2,"Do you want to update your detail","Updation",JOptionPane.YES_NO_OPTION);
				if(res==JOptionPane.YES_OPTION)
				{					
					pstmt.executeUpdate();					
					t2.setText("");
					t3.setText("");
					t4.setText("");
					t6.setText("");
					t7.setText("");
					t8.setText("");
					t9.setText("");
					c.removeAllItems();
					current_frame.setEnabled(true);
					dispose();
				}
			}
			catch(SQLException e)
			{
				JOptionPane.showMessageDialog(b2, "This ID and password is already exist");
			}
		}
		else if(b3==a.getSource())
		{
			dispose();
			last_frame.setEnabled(true);
		}
		else if(b4==a.getSource())
		{			
			StudentIssuedBook sib=new StudentIssuedBook(current_frame,str);
			sib.setVisible(true);
			dispose();
		}
	}
	
	@Override
	public void focusGained(FocusEvent a)
	{
		if(t2==a.getSource())
		{
			t2.selectAll();
		}
		else if(t3==a.getSource())
		{
			t3.selectAll();
		}
		else if(t4==a.getSource())
		{
			t4.selectAll();
		}
		else if(t6==a.getSource())
		{
			t6.selectAll();
		}
		else if(t7==a.getSource())
		{
			t6.selectAll();
		}		
		else if(t9==a.getSource())
		{
			t9.selectAll();
		}
	}
	@Override
	public void focusLost(FocusEvent arg0)
	{
	}
}