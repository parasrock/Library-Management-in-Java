import java.awt.event.*;
import java.io.IOException;
import java.net.Inet4Address;
import java.sql.*;

import javax.swing.*;

public class AddMenu extends JFrame implements ActionListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JMenuBar menubar;
	JMenu menu1,menu2,menu3,menu4;
	JMenuItem menuitem1,menuitem2,menuitem3,menuitem4,menuitem5,menuitem6,menuitem7,menuitem8,menuitem9,menuitem10,menuitem11;
	JFrame current_frame,menu_frame,pass_frame;
	Connectivity cc;
	Connection con;
	String id,pass;
	public AddMenu(JFrame menu_frame,JFrame pass_frame,String id,String pass)
	{
		super("Library ManageMant System");
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setLayout(null);
		this.id=id;
		this.pass=pass;
		current_frame=this;
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;
		menubar=new JMenuBar();
		menu1=new JMenu("Books");
		menu2=new JMenu("Students");
		menu3=new JMenu("ID");
		menu4=new JMenu("Others");
		setJMenuBar(menubar);
		menubar.add(menu1);
		menubar.add(menu2);
		menubar.add(menu3);
		menubar.add(menu4);
		menu1.addSeparator();
		menuitem1=new JMenuItem("Add Books");
		menu1.add(menuitem1);		
		menuitem1.setEnabled(false);
		menuitem1.addActionListener(this);
		menu1.addSeparator();
		menuitem2=new JMenuItem("Show Books");
		menu1.add(menuitem2);
		menuitem2.addActionListener(this);
		menu1.addSeparator();
		menuitem3=new JMenuItem("Search Books");
		menu1.add(menuitem3);
		menuitem3.addActionListener(this);
		menu1.addSeparator();
		menuitem4=new JMenuItem("Delete Book");
		menu1.add(menuitem4);
		menuitem4.addActionListener(this);
		menuitem5=new JMenuItem("Issue Books");
		menu2.add(menuitem5);
		menuitem5.addActionListener(this);
		menu2.addSeparator();
		menuitem6=new JMenuItem("Return Books");
		menu2.add(menuitem6);			
		menuitem6.addActionListener(this);
		menuitem11=new JMenuItem("View Profile");
		menu3.add(menuitem11);
		menuitem11.addActionListener(this);
		menu3.addSeparator();
		menuitem7=new JMenuItem("Change Password");
		menu3.add(menuitem7);
		menuitem7.addActionListener(this);
		menu3.addSeparator();
		menuitem8=new JMenuItem("Log out");
		menu3.add(menuitem8);
		menuitem8.addActionListener(this);
		menubar.add(menu4);
		AddPanel ap=new AddPanel(current_frame,menu_frame,pass_frame,id,pass);
		menuitem9=new JMenuItem("Help");
		menu4.add(menuitem9);
		menuitem9.addActionListener(this);
		menu4.addSeparator();
		menuitem10=new JMenuItem("Exit");
		menu4.add(menuitem10);
		menuitem10.addActionListener(this);
		add(ap);
		ap.setBounds(0, 3, getToolkit().getScreenSize().width,getToolkit().getScreenSize().height);
		addWindowListener(new WindowAdapter() { public void windowClosing(WindowEvent we){ 
			System.exit(0);			
		} });
	}
	@Override
	public void actionPerformed(ActionEvent a) 
	{		
		if(menuitem2==a.getSource())
		{
			ShowMenu am=new ShowMenu(menu_frame,pass_frame,1,id,pass);
			am.setVisible(true);
			dispose();
		}
		else if(menuitem3==a.getSource())
		{
			SearchMenu am=new SearchMenu(menu_frame,pass_frame,1,id,pass);
			am.setVisible(true);
			dispose();
		}
		else if(menuitem4==a.getSource())
		{
			DeleteMenu dm=new DeleteMenu(menu_frame,pass_frame,id,pass);
			dm.setVisible(true);
			dispose();
		}
		else if(menuitem5==a.getSource())
		{
			IssueMenu im=new IssueMenu(menu_frame,pass_frame,id,pass);
			im.setVisible(true);
			dispose();
		}
		else if(menuitem6==a.getSource())
		{
			ReturnMenu rm=new ReturnMenu(menu_frame,pass_frame,id,pass);
			rm.setVisible(true);
			dispose();
		}
		else if(menuitem7==a.getSource())
		{
			ChangePassword cp=new ChangePassword(current_frame,1,id);
			setEnabled(false);
			cp.setVisible(true);
		}
		else if(menuitem8==a.getSource())
		{
			try{
				cc=new Connectivity();
			}
			catch(IOException e){
				e.printStackTrace();
			}
			con=cc.getConn();
			try{
				PreparedStatement pstmt=con.prepareStatement("delete from session where ip=?");
				pstmt.setString(1,Inet4Address.getLocalHost().getHostAddress());
				pstmt.executeUpdate();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			pass_frame.setVisible(true);
			dispose();			
		}
		else if(menuitem9==a.getSource())
		{			
		}
		else if(menuitem10==a.getSource())
		{
			int result=JOptionPane.showConfirmDialog(menuitem10,"Choose Yes or NO","Exit",JOptionPane.YES_NO_OPTION);
			dispose();
			if(result == JOptionPane.YES_OPTION)
				System.exit(0);
			else
				current_frame.setVisible(true);
		}
		else if(menuitem11==a.getSource())
		{
			LibrarienDetails lb=new LibrarienDetails(current_frame,id,pass);
			lb.setVisible(true);
			setEnabled(false);
		}
	}	
}