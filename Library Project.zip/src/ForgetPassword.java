import java.awt.Font;
import java.awt.event.*;
import java.io.IOException;
import java.sql.*;
import javax.swing.*;

public class ForgetPassword extends JFrame implements ActionListener 
{	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel label1,label2,label3,label4,label5,label6;	
	JTextField textfield1,textfield2,textfield3,textfield4,textfield5;
	JButton button1,button2;
	String str;
	JComboBox<String> combobox;
	int xx;
	JFrame current_frame;
	public ForgetPassword(int x,final JFrame current_frame)
	{
		setSize(480,300);
		setLayout(null);
		xx=x;
		this.current_frame=current_frame;
		setLocationRelativeTo(this);
		label1=new JLabel("Forget password Menu");
		label1.setBounds(30, 10,250,25);
		label1.setFont(new Font(getName(),Font.ITALIC,20));
		add(label1);
		label2=new JLabel("Name");
		label2.setBounds(50, 50, 130, 20);
		add(label2);
		label3=new JLabel("Phone no");
		label3.setBounds(50, 85, 130, 20);
		add(label3);
		if(xx==1)
			label4=new JLabel("UserName");
		else if(xx==2)
			label4=new JLabel("ID");
		label4.setBounds(50, 120, 130, 20);
		add(label4);
		label5=new JLabel("Select your question");
		label5.setBounds(50, 155, 130, 20);
		add(label5);
		label6=new JLabel("Ans");
		label6.setBounds(50, 190, 130, 20);
		add(label6);
		textfield1=new JTextField();
		textfield1.setBounds(200,50, 150, 20);
		add(textfield1);
		textfield2=new JTextField();
		textfield2.setBounds(200,85, 150, 20);
		add(textfield2);
		textfield3=new JTextField();
		textfield3.setBounds(200,120, 150, 20);
		add(textfield3);
		combobox=new JComboBox<String>();		
		combobox.setBounds(200,155, 200, 20);
		add(combobox);
		combobox.addItem("What is your favourite Movie");
		combobox.addItem("What is your favourite TV chennel");
		combobox.addItem("What is your NickName");
		combobox.addItem("What is your favourite Book");
		combobox.addItem("What is your favourite song");		
		combobox.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent arg0)
			{
				str=(String)combobox.getSelectedItem();
				System.out.println(str);
			}
		});
		textfield4=new JTextField();
		textfield4.setBounds(200,190, 150, 20);
		add(textfield4);		
			
		button1=new JButton("Show Password");
		button1.setBounds(80, 230, 140, 20);
		add(button1);
		button2=new JButton("Back");
		button2.setBounds(250, 230, 120, 20);
		add(button2);
		button1.addActionListener(this);
		button2.addActionListener(this);
		addWindowListener(new WindowAdapter() { public void windowClosing(WindowEvent e)
		{
			dispose();
			current_frame.setEnabled(true);
		}
		});
	}
	@Override
	public void actionPerformed(ActionEvent e)
	{
		Connectivity cc=null;
		Connection con=null;
		if(button1==e.getSource())
		{
			try
			{
				cc=new Connectivity();
			}
			catch(IOException ioe)
			{
				ioe.printStackTrace();
			}
			con=cc.getConn();
			try
			{
				if(xx==1)
				{
					PreparedStatement pstmt=con.prepareStatement("select * from librarien where name=? and pn=? and un=? and qus=? and ans=?");
					pstmt.setString(1, textfield1.getText());
					pstmt.setString(2, textfield2.getText());
					pstmt.setString(3, textfield3.getText());
					pstmt.setString(4, str);
					pstmt.setString(5, textfield4.getText());
					ResultSet rs=pstmt.executeQuery();
					while(rs.next())
					{
						if(textfield1.getText().equals(rs.getString("name")) && textfield2.getText().equals(rs.getString("pn")) && textfield3.getText().equals(rs.getString("un")) && str.equals(rs.getString("qus")) && textfield4.getText().equals(rs.getString("ans")))
						{
							JOptionPane.showMessageDialog(button1, "Your Password is '"+rs.getString("pass")+"'");
						}
						else
						{
							JOptionPane.showMessageDialog(button1, "Wrong Details","ERROR",JOptionPane.ERROR_MESSAGE);
						}
					}
				}
				else if(xx==2)
				{
					PreparedStatement pstmt=con.prepareStatement("select * from student where name=? and phone_no=? and id=? and recovery_qus=? and ans=?");
					pstmt.setString(1, textfield1.getText());
					pstmt.setString(2, textfield2.getText());
					pstmt.setString(3, textfield3.getText());
					pstmt.setString(4, str);
					pstmt.setString(5, textfield4.getText());
					ResultSet rs=pstmt.executeQuery();
					while(rs.next())
					{
						if(textfield1.getText().equals(rs.getString("name")) && textfield2.getText().equals(rs.getString("phone_no")) && textfield3.getText().equals(rs.getString("id")) && str.equals(rs.getString("recovery_qus")) && textfield4.getText().equals(rs.getString("ans")))
						{
							JOptionPane.showMessageDialog(button1, "Your Password is '"+rs.getString("pass")+"'");
							dispose();
						}
						else
						{
							JOptionPane.showMessageDialog(button1, "Wrong Details","ERROR",JOptionPane.ERROR_MESSAGE);
						}
					}
				}
			}
			catch(SQLException ee)
			{
				ee.printStackTrace();
			}
		}
		else if(button2==e.getSource())
		{
			dispose();
			current_frame.setEnabled(true);
		}
	}	
}
