import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Calendar;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ShowPanel extends JPanel implements ActionListener,Runnable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JToolBar tb;
	JButton bb1,bb3,b,bb4,bb5,bb6,bb7;	
	Connectivity cc=null;
	Connection con=null;
	JTabbedPane tp;
	Calendar c;
	JFrame show_frame,menu_frame,pass_frame;
	JLabel l,l0,ll;
	DefaultTableModel dtm;
	int f=0,check;
	JScrollPane sp=null;
	String str1[]={"Book ID","Book Name","Author Name","Sale Price","Purchase Price","Quaantity"};
	int xx;
	Thread t,tt,thread,thread1,thread2;
	String str2,str3;
	public ShowPanel(final JFrame show_frame,final JFrame menu_frame,final JFrame pass_frame,int x,String str2,String str3)
	{
		setLayout(null);
		tb=new JToolBar();
		t=new Thread(this);
		xx=x;
		dtm=new DefaultTableModel(null,str1);
		this.show_frame=show_frame;
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;
		c=Calendar.getInstance();
		l0=new JLabel();
		l0.setBounds(getToolkit().getScreenSize().width-200,50,100,30);
		l0.setFont(new Font(getName(), Font.BOLD, 20));
		add(l0);
		this.str2=str2;
		this.str3=str3;
		tb=new JToolBar();
		if(xx==1)
		{
			bb1=new JButton(new ImageIcon("add.jpg"));
			bb1.setToolTipText("Add Books");
			tb.add(bb1);
			bb1.addActionListener(this);
		}
		tb.setBounds(0,0,getToolkit().getScreenSize().width,40);
		add(tb);		
		bb3=new JButton(new ImageIcon("search.jpg"));
		bb3.setToolTipText("Search Books");
		bb3.addActionListener(this);
		tb.add(bb3);
		if(xx==1)
		{
			bb4=new JButton(new ImageIcon("delete.jpg"));
			bb4.setToolTipText("Delete Books");
			bb4.addActionListener(this);
			tb.add(bb4);
			bb5=new JButton(new ImageIcon("issuebook.jpg"));
			bb5.setToolTipText("Issue Menu");
			tb.add(bb5);
			bb5.addActionListener(this);
			bb6=new JButton(new ImageIcon("returnBook.jpg"));
			bb6.setToolTipText("Return Books");
			tb.add(bb6);
			bb6.addActionListener(this);
			bb7=new JButton("Warning");
			tb.add(bb7);
			bb7.addActionListener(this);
		}
		thread=new Thread(this);
		setFocusable(true);
		addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent arg0) {}
			@Override
			public void keyReleased(KeyEvent arg0) {}
			@Override
			public void keyPressed(KeyEvent a) {
				if(a.getKeyChar()==KeyEvent.VK_ESCAPE)
				{
					thread.start();
				}
			}
		});
		if(xx==1)
		{
			tp=new JTabbedPane();
			tp.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
			tp.add("All Books",new AllBooks(show_frame,menu_frame,pass_frame,xx,str2,str3));
			tp.add("All Students",new AllStudent(show_frame,menu_frame,pass_frame,xx,str2,str3));
			tp.add("All Librariens",new AllLibrarien(show_frame,menu_frame,pass_frame,xx,str2,str3));
			tp.setBounds(0,60, getToolkit().getScreenSize().width, getToolkit().getScreenSize().height);
			add(tp);			
		}
		else if(xx==2)
		{
			JLabel l=new JLabel("All Books");
			l.setFont(new Font(getName(),Font.BOLD,30));
			l.setBounds(50, 50, 300, 40);
			add(l);
			JLabel lb=new JLabel(new ImageIcon("back.jpg"));
			lb.setBounds(1270, 50, 35, 35);
			add(lb);
			lb.addMouseListener(new MouseListener() {
				@Override
				public void mouseReleased(MouseEvent arg0) {}
				@Override
				public void mousePressed(MouseEvent arg0) {}
				@Override
				public void mouseExited(MouseEvent arg0) {}
				@Override
				public void mouseEntered(MouseEvent arg0) {}
				@Override
				public void mouseClicked(MouseEvent arg0) {
					menu_frame.setVisible(true);
					show_frame.dispose();
				}
			});
			l=new JLabel("");
			l.setFont(new Font(getName(),Font.ITALIC,40));
			l.setBounds(500, 300, 300, 50);
			add(l);
			JTable table=new JTable(dtm);
			table.setEnabled(false);
			sp=new JScrollPane(table);
			add(sp);
			sp.setBounds(120, 190, (getToolkit().getScreenSize().width)-250, 400);			
		}
		thread2=new Thread(this);
		thread2.start();
		t.start();
		thread1=new Thread(this);
		thread1.start();
	}

	@Override
	public void actionPerformed(ActionEvent a)
	{
		if(bb1==a.getSource())
		{
			AddMenu am=new AddMenu(menu_frame,pass_frame,str2,str3);
			am.setVisible(true);
			show_frame.dispose();
		}
		else if(bb3==a.getSource())
		{
			SearchMenu sm=new SearchMenu(menu_frame,pass_frame,xx,str2,str3);
			sm.setVisible(true);
			show_frame.dispose();
		}
		else if(b==a.getSource())
		{
			menu_frame.setVisible(true);
			show_frame.dispose();
		}
		else if(bb4==a.getSource())
		{
			DeleteMenu dm=new DeleteMenu(menu_frame,pass_frame,str2,str3);
			dm.setVisible(true);
			show_frame.dispose();			
		}
		else if(bb5==a.getSource())
		{
			IssueMenu dm=new IssueMenu(menu_frame,pass_frame,str2,str3);
			dm.setVisible(true);
			show_frame.dispose();			
		}
		else if(bb6==a.getSource())
		{
			ReturnMenu dm=new ReturnMenu(menu_frame,pass_frame,str2,str3);
			dm.setVisible(true);
			show_frame.dispose();			
		}
		else if(bb7==a.getSource())
		{
			Warning dm=new Warning(menu_frame,pass_frame,str2,str3);
			dm.setVisible(true);
			show_frame.dispose();			
		}
	}
	@Override
	public void run()
	{
		while(Thread.currentThread()==t)
		{
			c=Calendar.getInstance();
			l0.setText(c.get(Calendar.HOUR)+":"+c.get(Calendar.MINUTE)+":"+c.get(Calendar.SECOND));
			try
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		if(thread==Thread.currentThread())
		{
			menu_frame.setVisible(true);
			show_frame.dispose();
		}
		if(Thread.currentThread()==thread1 && xx==1)
		{
			try
			{
				cc=new Connectivity();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			con=cc.getConn();
			check=0;
			try
			{				
				PreparedStatement pstmt=con.prepareStatement("select * from book where q < 10");
				ResultSet rs=pstmt.executeQuery();
				while(rs.next())
				{
					bb7.setForeground(Color.RED);
					check=1;
				}
				if(check==0)
					bb7.setEnabled(false);
				else
					bb7.setEnabled(true);
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
		if(thread2==Thread.currentThread())
		{
			try
			{
				cc = new Connectivity();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}						
			con=cc.getConn();						
			String str[]=new String[7];			
			try
			{
				PreparedStatement pstmt=con.prepareStatement("select * from book");			
				ResultSet rs=pstmt.executeQuery();			
				while(rs.next())
				{
					str[0]=rs.getString("id");
					str[1]=rs.getString("bn");
					str[2]=rs.getString("an");
					str[3]=rs.getString("cat");
					str[4]=String.valueOf(rs.getInt("sp"));
					str[5]=String.valueOf(rs.getInt("pp"));
					str[6]=String.valueOf(rs.getInt("q"));				
					f=1;
					dtm.addRow(str);
				}
			}
			catch(SQLException sqle)
			{	
				sqle.printStackTrace();
			}
			if(f==0)
			{
				try{
					Thread.sleep(200);
				}
				catch(InterruptedException e){
					e.printStackTrace();
				}
				JOptionPane.showMessageDialog(this,"No Books Available","Error",JOptionPane.ERROR_MESSAGE);
			}
		}
	}
}