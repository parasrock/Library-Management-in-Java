import java.awt.Font;
import java.awt.event.*;
import java.sql.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class AllLibrarien extends JPanel implements Runnable 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JFrame show_frame,menu_frame,pass_frame;
	JLabel label1,label2,label3,label4;
	String id,pass;	
	Connectivity connect_to_db;
	int xx;
	JPanel current_panel;
	Connection connection;
	int size,f,d=0;	
	DefaultTableModel dtm;
	JTable table;
	JScrollPane sp;
	Thread thread;
	String title[]={"Name","Address","Phone No"};
	public AllLibrarien(final JFrame show_frame,final JFrame menu_frame,final JFrame pass_frame, final int xx,final String id,final String pass)
	{
		setLayout(null);
		this.show_frame=show_frame;
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;
		this.id=id;
		current_panel=this;
		this.xx=xx;
		this.pass=pass;
		label1=new JLabel("Librariens");
		label1.setBounds(50, 20, 200, 30);
		label1.setFont(new Font(getName(),Font.BOLD,20));
		add(label1);					
		label2=new JLabel(new ImageIcon("back.jpg"));
		label2.setBounds(1270, 10, 35, 35);
		add(label2);
		dtm=new DefaultTableModel(null,title);
		table=new JTable(dtm);
		table.setEnabled(false);
		sp=new JScrollPane(table);					
		add(sp);
		sp.setBounds(100, 100, (getToolkit().getScreenSize().width)-200, 450);
		label2.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent arg0){}
			@Override
			public void mousePressed(MouseEvent arg0){}
			@Override
			public void mouseExited(MouseEvent arg0){}
			@Override
			public void mouseEntered(MouseEvent arg0){}
			@Override
			public void mouseClicked(MouseEvent arg0)
			{
				menu_frame.setVisible(true);
				show_frame.dispose();
			}
		});
		try
		{
			connect_to_db = new Connectivity();
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}						
		connection=connect_to_db.getConn();									 						
		String data[]=new String[3];		
		try
		{
			PreparedStatement pstmt=connection.prepareStatement("select * from backup_librarien");			
			ResultSet rs=pstmt.executeQuery();			
			while(rs.next())
			{
				data[0]=rs.getString("name");							
				data[1]=rs.getString("add");
				data[2]=rs.getString("pn");							
				f=1;
				dtm.addRow(data);
			}
		}
		catch(SQLException sqle)
		{	
			sqle.printStackTrace();
		}			
		if(f==0)
			JOptionPane.showMessageDialog(current_panel, "No Librarien worked");
		current_panel.setFocusable(true);
		thread=new Thread(this);
		addKeyListener(new KeyListener() {			
			@Override
			public void keyTyped(KeyEvent arg0) {}
			@Override
			public void keyReleased(KeyEvent arg0) {}
			@Override
			public void keyPressed(KeyEvent a) {
				if(a.getKeyChar()==KeyEvent.VK_ESCAPE)
				{
					thread.start();
				}
			}
		});
	}	
	public void run()
	{
		menu_frame.setVisible(true);
		show_frame.dispose();
	}
}