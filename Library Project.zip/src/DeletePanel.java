import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

import javax.swing.*;

public class DeletePanel extends JPanel implements ActionListener,Runnable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JToolBar toolbar;
	JButton addtoolbutton,showtoolbutton,searchtoobutton,issuetoolbutton,returntoolbutton,bb7;
	JLabel label;
	JTabbedPane tabbedpane;
	JFrame delete_frame,menu_frame,pass_frame;
	String id,pass;
	int check;
	Thread thread,th,tt;
	Calendar calendar;
	public DeletePanel(JFrame delete_frame,JFrame menu_frame,JFrame pass_frame,String id,String pass)
	{
		setLayout(null);
		toolbar=new JToolBar();
		thread=new Thread(this);
		this.delete_frame=delete_frame;
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;
		label=new JLabel("");
		label.setBounds(getToolkit().getScreenSize().width-100,35,100,30);
		label.setFont(new Font(getName(), Font.BOLD, 20));
		add(label);
		this.id=id;
		this.pass=pass;
		addtoolbutton=new JButton(new ImageIcon("add.jpg"));
		addtoolbutton.setToolTipText("Add Books");
		toolbar.add(addtoolbutton);
		addtoolbutton.addActionListener(this);
		showtoolbutton=new JButton(new ImageIcon("view.jpg"));
		toolbar.add(showtoolbutton);
		toolbar.setBounds(0,0,getToolkit().getScreenSize().width,40);
		add(toolbar);		
		showtoolbutton.setToolTipText("Show Books");
		showtoolbutton.addActionListener(this);
		searchtoobutton=new JButton(new ImageIcon("search.jpg"));
		searchtoobutton.setToolTipText("Search Books");
		searchtoobutton.addActionListener(this);
		toolbar.add(searchtoobutton);
		issuetoolbutton=new JButton(new ImageIcon("issuebook.jpg"));
		issuetoolbutton.setToolTipText("Issue Menu");
		toolbar.add(issuetoolbutton);
		issuetoolbutton.addActionListener(this);
		returntoolbutton=new JButton(new ImageIcon("returnBook.jpg"));
		returntoolbutton.setToolTipText("Return Books");
		toolbar.add(returntoolbutton);
		returntoolbutton.addActionListener(this);
		bb7=new JButton("Warning");
		toolbar.add(bb7);
		bb7.addActionListener(this);
		tabbedpane=new JTabbedPane();
		tabbedpane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);		
		tabbedpane.add("Book Id",new DeleteBookID(delete_frame,menu_frame,id,pass));
		tabbedpane.add("Book Name",new DeleteBook(delete_frame,menu_frame,id,pass));
		tabbedpane.add("Author Name",new DeleteAuthor(delete_frame,menu_frame,id,pass));		
		tabbedpane.setBounds(0, 60,getToolkit().getScreenSize().width, getToolkit().getScreenSize().height);
		add(tabbedpane);
		thread.start();
		setFocusable(true);
		th=new Thread(this);
		addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent arg0) {}
			
			@Override
			public void keyReleased(KeyEvent arg0) {}
			
			@Override
			public void keyPressed(KeyEvent a) {
				if(a.getKeyChar()==KeyEvent.VK_ESCAPE)
				{
					th.start();
				}
			}
		});
		tt=new Thread(this);
		tt.start();
	}
	@Override
	public void actionPerformed(ActionEvent a)
	{
		if(addtoolbutton==a.getSource())
		{
			AddMenu am=new AddMenu(menu_frame,pass_frame,id,pass);
			am.setVisible(true);
			delete_frame.dispose();
		}
		else if(showtoolbutton==a.getSource())
		{
			ShowMenu sm=new ShowMenu(menu_frame,pass_frame,1,id,pass);
			sm.setVisible(true);
			delete_frame.dispose();
		}
		else if(searchtoobutton==a.getSource())
		{
			SearchMenu sm=new SearchMenu(menu_frame,pass_frame,1,id,pass);
			sm.setVisible(true);
			delete_frame.dispose();
		}		
		else if(issuetoolbutton==a.getSource())
		{
			IssueMenu sm=new IssueMenu(menu_frame,pass_frame,id,pass);
			sm.setVisible(true);
			delete_frame.dispose();
		}
		else if(returntoolbutton==a.getSource())
		{
			ReturnMenu sm=new ReturnMenu(menu_frame,pass_frame,id,pass);
			sm.setVisible(true);
			delete_frame.dispose();
		}
		else if(bb7==a.getSource())
		{
			Warning sm=new Warning(menu_frame,pass_frame,id,pass);
			sm.setVisible(true);
			delete_frame.dispose();
		}
	}
	@Override
	public void run()
	{
		Connectivity cc=null;
		Connection con=null;
		while(Thread.currentThread()==thread)
		{
			calendar=Calendar.getInstance();
			label.setText(calendar.get(Calendar.HOUR)+":"+calendar.get(Calendar.MINUTE)+":"+calendar.get(Calendar.SECOND));
			try
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		if(th==Thread.currentThread())
		{
			menu_frame.setVisible(true);
			delete_frame.dispose();
		}
		if(Thread.currentThread()==tt)
		{
			try
			{
				cc=new Connectivity();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			con=cc.getConn();
			check=0;
			try
			{				
				PreparedStatement pstmt=con.prepareStatement("select * from book where q < 10");
				ResultSet rs=pstmt.executeQuery();
				while(rs.next())
				{
					bb7.setForeground(Color.RED);
					check=1;
				}
				if(check==0)
					bb7.setEnabled(false);
				else
					bb7.setEnabled(true);
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
	}
}