import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class PanelPriceacc extends JPanel implements ActionListener,ItemListener
{	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton b;
	JRadioButton r1,r2;
	ButtonGroup bg;
	JTextField l;
	JFrame search_frame,menu_frame,pass_frame;
	DefaultTableModel dtm;
	String query;
	JLabel ll,l1;
	int xx,rp,size;
	String str,str1;
	public PanelPriceacc(final JFrame search_frame,final JFrame menu_frame,final JFrame pass_frame,int x,final String str,final String str1)
	{
		xx=x;
		setLayout(null);				
		this.search_frame=search_frame;
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;
		this.str=str;
		this.str1=str1;		
		bg=new ButtonGroup();		
		b=new JButton("Show");
		b.setBounds(750, 100, 100, 20);
		add(b);
		b.addActionListener(this);
		l=new JTextField("");
		l.setBounds(600, 100, 120, 20);		
		add(l);
		r1=new JRadioButton("Greater then");
		r1.setBounds(400, 70, 150, 20);
		add(r1);
		r2=new JRadioButton("Less then");
		r2.setBounds(400, 110, 150, 20);
		add(r2);				
		bg.add(r1);
		bg.add(r2);
		r1.addItemListener(this);
		r2.addItemListener(this);
		ll=new JLabel("");
		ll.setFont(new Font(getName(),Font.ITALIC,40));
		ll.setBounds(500, 300, 300, 50);
		add(ll);
		l1=new JLabel(new ImageIcon("back.jpg"));
		l1.setBounds(1270, 10, 35, 35);
		add(l1);
		l1.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent arg0){}
			@Override
			public void mousePressed(MouseEvent arg0){}
			@Override
			public void mouseExited(MouseEvent arg0){}
			@Override
			public void mouseEntered(MouseEvent arg0){}
			@Override
			public void mouseClicked(MouseEvent arg0)
			{
				menu_frame.setVisible(true);
				search_frame.dispose();
			}
		});
	}
	@Override
	public void actionPerformed(ActionEvent a)
	{			
		Connectivity cc=null;
		Connection con=null;
		int f=0,size=0;
		JScrollPane sp=null;
		String str1[]={"Book ID","Book Name","Author Name","Sale Price","Purchase Price","Quaantity"};
		if(b==a.getSource())
		{
			size=0;
			if(rp==0)
			{
				JOptionPane.showMessageDialog(b,"Please select any radio button","ERROR",JOptionPane.ERROR_MESSAGE);
			}
			else if(rp==1)
			{
				try
				{
					cc = new Connectivity();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}						
				con=cc.getConn();
				try
				{
					PreparedStatement pstmt=null;
					pstmt=con.prepareStatement(query);
					pstmt.setInt(1, Integer.parseInt(l.getText()));
					ResultSet rs=pstmt.executeQuery();
					while(rs.next())
					{
						size++;
						f=1;
					}
				}
				catch(SQLException sqle)
				{	
					sqle.printStackTrace();
				}
				if(f==1)
				{
					String str[][]=new String[size][6];
					int i=0;
					try
					{				
						PreparedStatement pstmt=null;								
						pstmt=con.prepareStatement(query);
						pstmt.setInt(1, Integer.parseInt(l.getText()));
						ResultSet rs=pstmt.executeQuery();			
						while(rs.next())
						{
							str[i][0]=String.valueOf(rs.getInt("id"));
							str[i][1]=rs.getString("bn");
							str[i][2]=rs.getString("an");
							str[i][3]=String.valueOf(rs.getInt("sp"));
							str[i][4]=String.valueOf(rs.getInt("pp"));
							str[i][5]=String.valueOf(rs.getInt("q"));
							i++;
						}
					}
					catch(SQLException sqle)
					{
						sqle.printStackTrace();
					}
					dtm=new DefaultTableModel(str,str1);
					JTable table=new JTable(dtm);
					sp=new JScrollPane(table);
					add(sp);
					table.setEnabled(false);		
					sp.setBounds(100, 160, (getToolkit().getScreenSize().width)-150, 400);
				}
				else
					JOptionPane.showMessageDialog(this,"No Books available","ERROR",JOptionPane.ERROR_MESSAGE);
			}
		}		
	}
	@Override
	public void itemStateChanged(ItemEvent arg0)
	{	
		if(r1==arg0.getSource())
		{
			query="select * from book where sp > ?";
			rp=1;
		}
		else if(r2==arg0.getSource())
		{
			query="select * from book where sp <= ?";
			rp=1;
		}
	}	
}