import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

import javax.swing.*;

public class SearchPanel extends JPanel implements ActionListener,Runnable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JToolBar tb;
	JButton bb1,bb2,bb4,bb5,bb6,bb7;
	JTabbedPane tp;
	Connectivity cc=null;
	Connection con=null;
	JLabel l0;
	JFrame search_frame,menu_frame,pass_frame;
	int xx,check;
	Thread t,thread,tt;
	Calendar c;
	String str,str1;
	public SearchPanel(final JFrame search_frame,final JFrame menu_frame,final JFrame pass_frame,int x,String str,String str1)
	{
		setLayout(null);
		tb=new JToolBar();
		xx=x;
		this.search_frame=search_frame;
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;
		this.str=str;
		this.str1=str1;
		t=new Thread(this);
		l0=new JLabel("");
		l0.setBounds(getToolkit().getScreenSize().width-100,35,100,30);
		l0.setFont(new Font(getName(), Font.BOLD, 20));
		add(l0);
		if(xx==1)
		{
			bb1=new JButton(new ImageIcon("add.jpg"));
			tb.add(bb1);
			bb1.addActionListener(this);
			bb1.setToolTipText("Add Books");
		}
		bb2=new JButton(new ImageIcon("view.jpg"));
		tb.add(bb2);		
		bb2.addActionListener(this);		
		bb2.setToolTipText("Show Books");
		if(xx==1)
		{
			bb4=new JButton(new ImageIcon("delete.jpg"));			
			bb4.setToolTipText("Delete Books");
			tb.add(bb4);
			bb4.addActionListener(this);
			bb5=new JButton(new ImageIcon("issuebook.jpg"));			
			bb5.setToolTipText("Issue Books");
			tb.add(bb5);
			bb5.addActionListener(this);
			bb6=new JButton(new ImageIcon("returnBook.jpg"));			
			bb6.setToolTipText("Return Books");
			tb.add(bb6);
			bb6.addActionListener(this);
			bb7=new JButton("Warning");
			tb.add(bb7);
			bb7.addActionListener(this);
		}
		tb.setBounds(0, 0,getToolkit().getScreenSize().width,40);
		add(tb);		
		tp=new JTabbedPane();
		tp.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
		tp.add("Book Id",new PanelBookID(search_frame,menu_frame,pass_frame,xx,str,str1));
		tp.add("Book Name",new PanelBookName(search_frame,menu_frame,pass_frame,xx,str,str1));
		tp.add("Author Name",new PanelAuthorName(search_frame,menu_frame,pass_frame,xx,str,str1));
		tp.add("Price according",new PanelPriceacc(search_frame,menu_frame,pass_frame,xx,str,str1));
		tp.add("Category according",new PanelBookCategory(search_frame,menu_frame,pass_frame,xx,str,str1));
		tp.setBounds(0, 60, getToolkit().getScreenSize().width, getToolkit().getScreenSize().height);
		add(tp);
		t.start();
		setFocusable(true);
		thread=new Thread(this);
		addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent arg0) {}
			@Override
			public void keyReleased(KeyEvent arg0) {}
			@Override
			public void keyPressed(KeyEvent a) {
				if(a.getKeyChar()==KeyEvent.VK_ESCAPE)
				{
					thread.start();
				}
			}
		});
		tt=new Thread(this);
		tt.start();
	}
	@Override
	public void actionPerformed(ActionEvent a)
	{
		if(bb1==a.getSource())
		{
			AddMenu am=new AddMenu(menu_frame,pass_frame,str,str1);
			am.setVisible(true);
			search_frame.dispose();
		}
		else if(bb2==a.getSource())
		{
			ShowMenu sm=new ShowMenu(menu_frame,pass_frame,xx,str,str1);
			sm.setVisible(true);
			search_frame.dispose();
		}
		else if(bb4==a.getSource())
		{
			DeleteMenu dm=new DeleteMenu(menu_frame,pass_frame,str,str1);
			dm.setVisible(true);
			search_frame.dispose();
		}
		else if(bb5==a.getSource())
		{
			IssueMenu dm=new IssueMenu(menu_frame,pass_frame,str,str1);
			dm.setVisible(true);
			search_frame.dispose();
		}
		else if(bb6==a.getSource())
		{
			ReturnMenu dm=new ReturnMenu(menu_frame,pass_frame,str,str1);
			dm.setVisible(true);
			search_frame.dispose();
		}
		else if(bb7==a.getSource())
		{
			Warning dm=new Warning(menu_frame,pass_frame,str,str1);
			dm.setVisible(true);
			search_frame.dispose();
		}
	}
	@Override
	public void run()
	{
		while(Thread.currentThread()==t)
		{
			c=Calendar.getInstance();
			l0.setText(c.get(Calendar.HOUR)+":"+c.get(Calendar.MINUTE)+":"+c.get(Calendar.SECOND));
			try
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		if(Thread.currentThread()==thread)
		{
			menu_frame.setVisible(true);
			search_frame.dispose();
		}
		if(Thread.currentThread()==tt && xx==1)
		{
			try
			{
				cc=new Connectivity();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			con=cc.getConn();
			check=0;
			try
			{				
				PreparedStatement pstmt=con.prepareStatement("select * from book where q < 10");
				ResultSet rs=pstmt.executeQuery();
				while(rs.next())
				{
					bb7.setForeground(Color.RED);
					check=1;
				}
				if(check==0)
					bb7.setEnabled(false);
				else
					bb7.setEnabled(true);
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
	}
}