import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class AllStudent extends JPanel implements Runnable 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JFrame show_frame,menu_frame,pass_frame;
	JLabel label1,label2,label3,label4;
	String id,pass,title[]={"Student ID","Student Name","Section","Branch","Book Issued","Phone no","Address","Due"};
	Connectivity connect_to_db;
	int xx,cdue,size,f,d=0;
	Connection connection;	
	Thread thread;
	DefaultTableModel dtm;
	JTable table;
	JScrollPane sp;
	public AllStudent(final JFrame show_frame,final JFrame menu_frame,final JFrame pass_frame,final int xx,final String id,final String pass)
	{
		setLayout(null);
		this.show_frame=show_frame;
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;
		this.id=id;
		this.xx=xx;
		this.pass=pass;
		label1=new JLabel("Students");
		label1.setBounds(50, 20, 200, 30);
		label1.setFont(new Font(getName(),Font.BOLD,20));
		add(label1);
		label2=new JLabel("All Students");
		label2.setBounds(200, 70, 150, 20);
		add(label2);
		label3=new JLabel("All Students with due");
		label3.setBounds(600, 70, 150, 20);
		add(label3);				
		label4=new JLabel(new ImageIcon("back.jpg"));
		label4.setBounds(1270, 10, 35, 35);
		add(label4);
		dtm=new DefaultTableModel(null,title);						
		table=new JTable(dtm);
		sp=new JScrollPane(table);
		add(sp);
		sp.setBounds(100, 150, (getToolkit().getScreenSize().width)-200, 350);
		setFocusable(true);
		addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent arg0) {}
			@Override
			public void keyReleased(KeyEvent arg0) {}
			@Override
			public void keyPressed(KeyEvent a) {
				if(a.getKeyChar()==KeyEvent.VK_ESCAPE)
				{
					thread.start();
				}
			}
		});
		label4.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent arg0){}
			@Override
			public void mousePressed(MouseEvent arg0){}
			@Override
			public void mouseExited(MouseEvent arg0){}
			@Override
			public void mouseEntered(MouseEvent arg0){}
			@Override
			public void mouseClicked(MouseEvent arg0)
			{
				menu_frame.setVisible(true);
				show_frame.dispose();
			}
		});
		try
		{
			connect_to_db = new Connectivity();
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}						
		connection=connect_to_db.getConn();
		label2.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent arg0){}
			@Override
			public void mousePressed(MouseEvent arg0){}
			@Override
			public void mouseExited(MouseEvent arg0){}
			@Override
			public void mouseEntered(MouseEvent arg0){}
			@Override
			public void mouseClicked(MouseEvent arg0)
			{
				while(dtm.getRowCount()!=0)
						dtm.removeRow(0);
				f=0;
				String data[]=new String[8];				
				int ff=0;
				try
				{
					PreparedStatement pstmt=connection.prepareStatement("select * from student");
					ResultSet rs=pstmt.executeQuery();
					while(rs.next())
					{
						cdue=0;
						ff=0;						
						data[0]=rs.getString("id");
						data[1]=rs.getString("name");
						data[2]=rs.getString("section");
						data[3]=rs.getString("Branch");
						data[4]=String.valueOf(rs.getInt("ib"));
						data[5]=rs.getString("pn");
						data[6]=rs.getString("add");														
							try
							{
								PreparedStatement pstmt1=connection.prepareStatement("select book_issued,DATEDIFF(CURDATE(),issued_date)+1 from transaction where sid=? and return_date=?");
								pstmt1.setString(1, rs.getString("id"));
								pstmt1.setString(2, "");
								ResultSet rs1=pstmt1.executeQuery();							
								while(rs1.next())
								{
									ff=1;
									if(rs1.getInt(2)>15)
									cdue+=(rs1.getInt(1)*rs1.getInt(2));										
								}
							}
							catch(Exception ee)
							{
								ee.printStackTrace();
							}
							if(ff==1)
								data[7]=String.valueOf(cdue);
							else
							data[7]="0";
							f=1;
							dtm.addRow(data);
						}
					}
					catch(SQLException sqle)
					{	
						sqle.printStackTrace();
					}
					if(f==0)
						JOptionPane.showMessageDialog(label2, "No Student Found");											
				}
		});		
		label3.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent arg0){}
			@Override
			public void mousePressed(MouseEvent arg0){}
			@Override
			public void mouseExited(MouseEvent arg0){}
			@Override
			public void mouseEntered(MouseEvent arg0){}
			@Override
			public void mouseClicked(MouseEvent arg0)
			{
				while(dtm.getRowCount()!=0)
					dtm.removeRow(0);
				f=0;
				String data[]=new String[9];
				cdue=0;
				int ff=0;
				try
				{
					PreparedStatement pstmt=connection.prepareStatement("select * from student");			
					ResultSet rs=pstmt.executeQuery();			
					while(rs.next())
					{
						cdue=0;
						ff=0;
						try
						{
							PreparedStatement pstmt1=connection.prepareStatement("select book_issued,DATEDIFF(CURDATE(),issued_date)+1 from transaction where sid=? and return_date=?");
							pstmt1.setString(1, rs.getString("id"));
							pstmt1.setString(2, "");
							ResultSet rs1=pstmt1.executeQuery();
							while(rs1.next())
							{
								if(rs1.getInt(2)>15)
								{
									ff=1;
									cdue+=(rs1.getInt(1)*rs1.getInt(2));
								}
							}
						}					
						catch(Exception ee){
								ee.printStackTrace();
						}					
						if(ff==1)
						{
							data[0]=rs.getString("id");
							data[1]=rs.getString("name");
							data[2]=rs.getString("section");
							data[3]=rs.getString("Branch");
							data[4]=String.valueOf(rs.getInt("ib"));
							data[5]=rs.getString("pn");
							data[6]=rs.getString("add");
							data[7]=String.valueOf(cdue);
							f=1;
							dtm.addRow(data);
						}							
					}
				}
				catch(Exception e) {
					e.printStackTrace();
				}				
				if(f==0)
					JOptionPane.showMessageDialog(label3, "No Student Found");
				table.setEnabled(false);						
			}
		});
	}	
	public void run(){
		if(Thread.currentThread()==thread)
		{
			menu_frame.setVisible(true);
			show_frame.dispose();
		}
	}
}