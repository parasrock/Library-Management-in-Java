import java.awt.Font;
import java.awt.event.*;
import java.io.IOException;
import java.sql.*;
import java.util.TreeSet;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class PanelAuthorName extends JPanel implements ActionListener
{	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton b,b1;	
	JFrame search_frame,menu_frame,pass_frame;
	JLabel l1,l2,ll,l;
	JComboBox<String> c;
	JTable table;
	DefaultTableModel dtm;
	TreeSet<String> ts;
	Connectivity cc=null;	
	Connection con=null;
	int xx,f;
	JScrollPane sp;
	String str,str1,y;
	static String s;
	public PanelAuthorName(final JFrame search_frame,final JFrame menu_frame,final JFrame pass_frame,int x,final String str,final String str1)
	{
		String str2[]={"Book ID","Book Name","Author Name","Category","Sale Price","Purchase Price","Quaantity"};
		setLayout(null);
		xx=x;
		s="";
		b1=new JButton("clear");
		this.search_frame=search_frame;
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;
		this.str=str;
		this.str1=str1;
		l1=new JLabel("Show All Books of the Author");
		l1.setFont(new Font(getName(),Font.ITALIC,20));
		l1.setBounds(50, 30, 400, 30);
		add(l1);		
		l2=new JLabel("Book Name");
		l2.setBounds(250, 100, 120, 20);
		add(l2);
		b1.setBounds(720, 100, 100, 20);
		add(b1);
		b1.addActionListener(this);		
		b=new JButton("Show");
		b.setBounds(600, 100, 100, 20);
		add(b);
		ts=new TreeSet<String>();
		b.addActionListener(this);		
		c=new JComboBox<String>();
		c.setBounds(400, 100, 120, 20);
		add(c);
		c.setEditable(true);
		c.getEditor().setItem((String)"");
		ll=new JLabel("");
		ll.setFont(new Font(getName(),Font.ITALIC,40));
		ll.setBounds(500, 300, 300, 50);
		add(ll);
		l=new JLabel(new ImageIcon("back.jpg"));
		l.setBounds(1270, 10, 35, 35);
		add(l);
		dtm=new DefaultTableModel(null,str2);
		table=new JTable(dtm);
		sp=new JScrollPane(table);
		add(sp);
		sp.setBounds(80, 200, (getToolkit().getScreenSize().width)-150, 300);
		l.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent arg0){}
			@Override
			public void mousePressed(MouseEvent arg0){}
			@Override
			public void mouseExited(MouseEvent arg0){}
			@Override
			public void mouseEntered(MouseEvent arg0){}
			@Override
			public void mouseClicked(MouseEvent arg0)
			{
				menu_frame.setVisible(true);
				search_frame.dispose();
			}
		});		
		((JTextField)c.getEditor().getEditorComponent()).addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent arg0){}
			@Override
			public void keyReleased(KeyEvent arg0){}
			@Override
			public void keyPressed(KeyEvent arg0) {								
				try
				{
					cc=new Connectivity();
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
				con=cc.getConn();
				try
				{
					PreparedStatement pstmt=con.prepareStatement("select * from book where an like '"+((JTextField)c.getEditor().getEditorComponent()).getText()+arg0.getKeyChar()+"%'");
					ResultSet rs=pstmt.executeQuery();			
					c.removeAllItems();
					ts.clear();
					while(rs.next())
						ts.add(rs.getString("an"));
					for(String str:ts)
						c.addItem(str);					
					((JTextField)c.getEditor().getEditorComponent()).setText(s);
					if((arg0.getKeyChar()>='a' && arg0.getKeyChar()<='z') || (arg0.getKeyChar()>='A' && arg0.getKeyChar()<='Z') || (arg0.getKeyChar()>='0' && arg0.getKeyChar()<='9'))
						s=s+(arg0.getKeyChar());
					if(arg0.getKeyChar()==KeyEvent.VK_BACK_SPACE)
						if(s.length()!=0)
							s=s.substring(0,s.length()-1);
				}
				catch(SQLException e){
					e.printStackTrace();
				}
			}
		});		
	}
	@Override
	public void actionPerformed(ActionEvent a)
	{			
		Connectivity cc=null;
		Connection con=null;
		if(b==a.getSource())
		{
			try
			{
				cc = new Connectivity();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}						
			con=cc.getConn();			
			String str[]=new String[7];			
			try
			{
				PreparedStatement pstmt=con.prepareStatement("select * from book where an = ?");
				pstmt.setString(1,((JTextField)c.getEditor().getEditorComponent()).getText());
				ResultSet rs=pstmt.executeQuery();			
				while(rs.next())
				{
					str[0]=String.valueOf(rs.getInt("id"));
					str[1]=rs.getString("bn");
					str[2]=rs.getString("an");
					str[3]=rs.getString("cat");
					str[4]=String.valueOf(rs.getInt("sp"));
					str[5]=String.valueOf(rs.getInt("pp"));
					str[6]=String.valueOf(rs.getInt("q"));
					f=1;
					dtm.addRow(str);
				}
			}
			catch(SQLException sqle)
			{	
				sqle.printStackTrace();
			}
			if(f==0)
				JOptionPane.showMessageDialog(b,"No books available","ERROR",JOptionPane.ERROR_MESSAGE);
		}
		else if(b1==a.getSource())
		{
			((JTextField)c.getEditor().getEditorComponent()).setText("");
			ll.setText("");
			while(dtm.getRowCount()!=0)
				dtm.removeRow(0);
			s="";
		}							
	}		
}