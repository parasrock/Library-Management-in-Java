import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.sql.*;
import java.util.LinkedList;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class AllBooks extends JPanel implements ActionListener,Runnable
{		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JFrame show_frame,menu_frame,pass_frame;	
	JLabel label1,label2;
	String id,pass;
	JButton button;
	Connectivity connect_to_db;	
	Connection connection;	
	int size,f,xx,count;
	final LinkedList<Integer> al=new LinkedList<Integer>();
	final LinkedList<Integer> ll=new LinkedList<Integer>();
	JTable table;
	Thread thread;
	JScrollPane sp;
	DefaultTableModel dtm;	
	public AllBooks(final JFrame show_frame,final JFrame menu_frame,final JFrame pass_frame,final int xx,final String id,final String pass)
	{
		String title[]={"Book ID","Book Name","Author Name","Sale Price","Purchase Price","Quaantity"};
		setLayout(null);
		this.show_frame=show_frame;
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;
		this.id=id;
		this.xx=xx;
		this.pass=pass;
		label1=new JLabel("All Books");
		label1.setBounds(50, 20, 200, 30);
		label1.setFont(new Font(getName(),Font.BOLD,20));
		add(label1);
		button=new JButton("Delete Book");
		button.setBounds(550, 520, 150, 20);
		add(button);
		button.addActionListener(this);
		label2=new JLabel(new ImageIcon("back.jpg"));
		label2.setBounds(1270, 10, 35, 35);
		add(label2);
		dtm=new DefaultTableModel(null,title);
		table=new JTable(dtm);
		sp=new JScrollPane(table);
		add(sp);
		sp.setBounds(100, 100, (getToolkit().getScreenSize().width)-200, 350);
		label2.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent arg0){}
			@Override
			public void mousePressed(MouseEvent arg0){}
			@Override
			public void mouseExited(MouseEvent arg0){}
			@Override
			public void mouseEntered(MouseEvent arg0){}
			@Override
			public void mouseClicked(MouseEvent arg0)
			{
				menu_frame.setVisible(true);
				show_frame.dispose();
			}
		});
		table.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent arg0){}
			@Override
			public void mousePressed(MouseEvent arg0){}
			@Override
			public void mouseExited(MouseEvent arg0){}
			@Override
			public void mouseEntered(MouseEvent arg0){}
			@Override
			public void mouseClicked(MouseEvent arg0)
			{				
				while(!al.isEmpty())
					al.remove(0);
				while(!ll.isEmpty())
					ll.remove(0);
				int a[]=table.getSelectedRows();
				for(int i=0;i<a.length;i++)
				{
					al.add(a[i]);
					ll.add(Integer.parseInt((String)dtm.getValueAt(a[i],0)));
				}				
			}
		});
		thread=new Thread(this);
		thread.start();
	}
	@Override
	public void actionPerformed(ActionEvent e)
	{
		Connection con=null;
		Connectivity cc=null;
		if(button==e.getSource())
		{
			try
			{
				cc=new Connectivity();
			}
			catch(IOException ee)
			{
				ee.printStackTrace();
			}
			con=cc.getConn();			
			PreparedStatement pstmt=null;
			int res=JOptionPane.showConfirmDialog(button,"Do you want to delete books","Deletion",JOptionPane.YES_NO_OPTION);
			if(res==JOptionPane.YES_OPTION)
			{			
				try
				{
					int count=0;
					for(int l:al)
					{						
						dtm.removeRow(l-count);
						count++;
					}					
					for(int l:ll)
					{
						pstmt=con.prepareStatement("delete from book where id=?");
						pstmt.setInt(1,l);
						pstmt.executeUpdate();						
					}
					JOptionPane.showMessageDialog(button,"Books Deleted","Information",JOptionPane.INFORMATION_MESSAGE);
				}
				catch(SQLException ee)
				{
					ee.printStackTrace();
				}				
			}
		}
	}
	@Override
	public void run() {
		if(thread==Thread.currentThread())
		{
			try
			{
				connect_to_db = new Connectivity();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}						
			connection=connect_to_db.getConn();						
			String data[]=new String[6];		
			try
			{
				PreparedStatement pstmt=connection.prepareStatement("select * from book");			
				ResultSet rs=pstmt.executeQuery();			
				while(rs.next())
				{
					data[0]=String.valueOf(rs.getInt("id"));
					data[1]=rs.getString("bn");
					data[2]=rs.getString("an");
					data[3]=String.valueOf(rs.getInt("sp"));
					data[4]=String.valueOf(rs.getInt("pp"));
					data[5]=String.valueOf(rs.getInt("q"));
					dtm.addRow(data);
					f=1;
				}
			}
			catch(SQLException sqle)
			{	
				sqle.printStackTrace();
			}
			if(f==0)
			{
				try{
					Thread.sleep(200);
				}
				catch(InterruptedException e){
					e.printStackTrace();
				}
				JOptionPane.showMessageDialog(this,"No Books available","ERROR",JOptionPane.ERROR_MESSAGE);
			}
		}
	}
}