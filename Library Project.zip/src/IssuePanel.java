import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import java.io.IOException;
import java.sql.*;
import java.util.Calendar;

import javax.swing.*;

public class IssuePanel extends JPanel implements ActionListener,Runnable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JToolBar tb;
	JLabel l1,l2,l3,l4,l6,l7,l,l5,ll,l0;
	JTextField t1,t2,t3,t4,t7,t,t5;
	JButton b1,b2,b3,bb1,bb2,bb3,bb4,b,b4,bb6,bb7;
	JFrame issue_frame,menu_frame,pass_frame;
	Thread t0,tt,thread,thread1;
	int y,f,x,check;
	Calendar c;
	String str,str1;
	public IssuePanel(JFrame issue_frame,JFrame menu_frame,JFrame pass_frame,String str,String str1)
	{
		setLayout(null);		
		this.issue_frame=issue_frame;
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;
		t0=new Thread(this);
		l0=new JLabel("");
		l0.setBounds(getToolkit().getScreenSize().width-100,45,100,30);
		l0.setFont(new Font(getName(), Font.BOLD, 20));
		add(l0);
		this.str=str;
		this.str1=str1;
		Calendar c=Calendar.getInstance();
		ll=new JLabel("Issue Books");
		ll.setFont(new Font(getName(),Font.ITALIC,30));
		ll.setBounds(150, 70, 300, 50);
		add(ll);
		l=new JLabel("Student id");
		l.setBounds(500, 150, 100, 25);
		add(l);
		t=new JTextField();
		t.setBounds(620, 150, 100, 25);
		add(t);
		b=new JButton("SUBMIT");
		b.setBounds(760, 150, 100, 25);
		add(b);
		l1=new JLabel("Book ID");		
		l1.setBounds(550,250, 150, 20);
		add(l1);		
		t1=new JTextField();
		t1.setBounds(650,250, 150, 20);
		add(t1);
		t1.setEnabled(false);
		thread=new Thread(this);
		setFocusable(true);
		addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent arg0) {}
			@Override
			public void keyReleased(KeyEvent arg0) {}
			@Override
			public void keyPressed(KeyEvent a) {
				if(a.getKeyChar()==KeyEvent.VK_ESCAPE)
				{
					thread.start();
				}
			}
		});
		t1.addFocusListener(new FocusListener() {
			
			@Override
			public void focusLost(FocusEvent arg0)
			{
				int flag=0;
				Connection con=null;
				Connectivity cc=null;
				try
				{
					cc = new Connectivity();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
				con=cc.getConn();			
				try
				{
					PreparedStatement pstmt=con.prepareStatement("select * from book where id=?");
					pstmt.setInt(1,Integer.parseInt(t1.getText()));
					ResultSet rs=pstmt.executeQuery();
					while(rs.next())
					{
						flag=1;
						PreparedStatement pstmt1=con.prepareStatement("select bid from transaction where sid=? and return_date=?");
						pstmt1.setString(1,t.getText());
						pstmt1.setString(2,"");
						ResultSet rs1=pstmt1.executeQuery();
						f=1;
						while(rs1.next())
						{
							if(rs1.getInt(1)==Integer.parseInt(t1.getText()))
							{								
								f=0;
								break;
							}
							else
								f=1;							
						}
						if(f==1)
						{
							t2.setText(rs.getString("bn"));
							t3.setText(rs.getString("an"));
							t4.setText(String.valueOf(rs.getInt("sp")));
							x=rs.getInt("q");
						}
						else if(f==0)
						{
							t1.setText("");
							t1.setEnabled(false);
							t2.setEnabled(false);
							t3.setEnabled(false);
							t4.setEnabled(false);
							JOptionPane.showMessageDialog(t1,"You already have this book","",JOptionPane.INFORMATION_MESSAGE);
						}
					}
					if(flag==0)
					{
						JOptionPane.showMessageDialog(t1,"No Book Available","Error",JOptionPane.ERROR_MESSAGE);
						t1.setText("");
					}
				}
				catch(Exception sqle)
				{	
					sqle.printStackTrace();
				}
			}
			@Override
			public void focusGained(FocusEvent arg0){}
		});
		l2=new JLabel("Book Name");
		l2.setBounds(550,290, 150, 20);
		add(l2);
		t2=new JTextField();
		t2.setBounds(650,290, 150, 20);
		add(t2);
		t2.setEnabled(false);
		l3=new JLabel("Author Name");
		l3.setBounds(550, 330, 150, 20);
		add(l3);
		t3=new JTextField();
		t3.setBounds(650, 330, 150, 20);
		add(t3);
		t3.setEnabled(false);
		l4=new JLabel("Sale price");
		l4.setBounds(550, 370, 150, 20);
		add(l4);		
		t4=new JTextField();		
		t4.setBounds(650, 370, 150, 20);
		add(t4);
		t4.setEnabled(false);
		l5=new JLabel("Issued date");
		l5.setBounds(550, 410, 150, 20);
		add(l5);
		t5=new JTextField();		
		t5.setBounds(650, 410, 150, 20);
		t5.setText((String)(c.get(Calendar.DAY_OF_MONTH)+"/"+(c.get(Calendar.MONTH)+1)+"/"+c.get(Calendar.YEAR)));
		add(t5);		
		t5.setEnabled(false);		
		t4.setEnabled(false);		
		b.addActionListener(this);
		b1=new JButton("Check Book");
		b1.setBounds(400, 500, 110, 20);
		b1.addActionListener(this);
		add(b1);
		b2=new JButton("Issue Book");
		b2.setBounds(530, 500, 110, 20);
		b2.addActionListener(this);
		add(b2);
		b3=new JButton("Clear");
		b3.setBounds(660, 500, 110, 20);
		b3.addActionListener(this);
		add(b3);		
		b4=new JButton("Cancel");
		b4.setBounds(790, 500, 110, 20);
		b4.addActionListener(this);
		add(b4);
		tb=new JToolBar();
		bb1=new JButton(new ImageIcon("add.jpg"));
		tb.add(bb1);
		bb1.addActionListener(this);
		bb2=new JButton(new ImageIcon("view.jpg"));
		tb.add(bb2);
		tb.setBounds(0,0,getToolkit().getScreenSize().width,40);
		add(tb);		
		bb2.setToolTipText("Show Books");		
		bb3=new JButton(new ImageIcon("search.jpg"));
		bb3.setToolTipText("Search Books");
		bb3.addActionListener(this);
		tb.add(bb3);
		bb4=new JButton(new ImageIcon("delete.jpg"));
		bb4.setToolTipText("Delete Books");
		bb4.addActionListener(this);
		tb.add(bb4);
		bb6=new JButton(new ImageIcon("returnBook.jpg"));
		bb6.setToolTipText("Return Books");
		tb.add(bb6);
		bb6.addActionListener(this);
		bb2.addActionListener(this);
		bb7=new JButton("Warning");
		tb.add(bb7);
		bb7.addActionListener(this);
		t0.start();
		thread1=new Thread(this);
		thread1.start();
	}
	@Override
	public void actionPerformed(ActionEvent a)
	{
		Connection con=null;
		Connectivity cc=null;
		int flag=0;
		if(b==a.getSource())
		{
				try
				{
					cc = new Connectivity();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}						
				con=cc.getConn();				
				try
				{
					PreparedStatement pstmt=con.prepareStatement("select * from student where id=?");
					pstmt.setString(1,t.getText());
					ResultSet rs=pstmt.executeQuery();
					while(rs.next())
					{
						t1.setEnabled(true);
						t2.setEnabled(true);
						t3.setEnabled(true);
						t4.setEnabled(true);
						y=rs.getInt("ib");
						flag=1;
						break;
					}
				}
				catch(SQLException sqle)
				{
					sqle.printStackTrace();
				}
				if(flag==0)
				{
					JOptionPane.showMessageDialog(b, "You are not authorized for issue books");
					t.setText("");
				}
				setFocusable(true);
		}		
		else if(b2==a.getSource())
		{
			try{
				cc=new Connectivity();				
			}
			catch(IOException e){
				e.printStackTrace();
			}
			con=cc.getConn();
			if(x>1)
			{
				try
				{
					x=x-1;
					if(y+1<=5)
					{
						if(f==1)
						{
							try
							{
								PreparedStatement pstmt=con.prepareStatement("update book set q=? where id=?");											
								PreparedStatement pstmt2=con.prepareStatement("insert into transaction values(?,?,?,CURDATE(),?,?)");
								PreparedStatement pstmt3=con.prepareStatement("update student set ib=? where id=?");
								PreparedStatement pstmt4=con.prepareStatement("update backup_student set ib=? where id=?");
								pstmt.setInt(1,x);
								pstmt.setInt(2,Integer.parseInt(t1.getText()));
								pstmt2.setInt(1,Integer.parseInt(t1.getText()));
								pstmt2.setString(2,t.getText());
								pstmt2.setInt(3,1);								
								pstmt2.setString(4,(String)(c.get(Calendar.HOUR)+":"+c.get(Calendar.MINUTE)+":"+c.get(Calendar.SECOND)));
								pstmt2.setString(5,"");
								System.out.println(y);
								pstmt3.setInt(1,y+1);
								pstmt3.setString(2,t.getText());
								pstmt4.setInt(1, y+1);
								pstmt4.setString(2,t.getText());
								int x1=JOptionPane.showConfirmDialog(b2,"Want to Issue Book","Issue Book",JOptionPane.YES_NO_OPTION);
								if(x1==JOptionPane.YES_OPTION)
								{
									pstmt.executeUpdate();
									pstmt2.executeUpdate();
									pstmt3.executeUpdate();
									pstmt4.executeUpdate();
									y=y+1;
									JOptionPane.showConfirmDialog(b2,"Books Issued","Message",JOptionPane.PLAIN_MESSAGE);
									t1.setText("");
									t2.setText("");
									t3.setText("");
									t4.setText("");
								}					
							}
							catch(Exception e)
							{
								e.printStackTrace();
							}
						}
						else
						{
							JOptionPane.showMessageDialog(b1, "Book Not Found");
						}					
					}
					else
					{
						JOptionPane.showMessageDialog(b1, "You cannot issued more than 5 books\nYour current issued_books is"+y);
						t.setText("");				
						t1.setText("");
						t2.setText("");
						t3.setText("");
						t4.setText("");
						t1.setEnabled(false);
						t2.setEnabled(false);
						t3.setEnabled(false);
						t4.setEnabled(false);
						t5.setEnabled(false);
					}
				}
				catch(NumberFormatException nfe)
				{
					JOptionPane.showMessageDialog(b1, "Please Enter valid values");
				}
			}
			else
				JOptionPane.showMessageDialog(b2,"Sorry, we have "+x+" books in Library Today");
			setFocusable(true);
		}
		else if(b3==a.getSource())
		{
			t1.setText("");
			t2.setText("");
			t3.setText("");
			t4.setText("");
			setFocusable(true);
		}
		else if(bb1==a.getSource())
		{
			AddMenu m=new AddMenu(menu_frame,pass_frame,str,str1);
			m.setVisible(true);
			issue_frame.dispose();
		}
		else if(bb2==a.getSource())
		{
			ShowMenu am=new ShowMenu(menu_frame,pass_frame,1,str,str1);
			am.setVisible(true);
			issue_frame.dispose();
		}
		else if(bb3==a.getSource())
		{
			SearchMenu sm=new SearchMenu(menu_frame,pass_frame,1,str,str1);
			sm.setVisible(true);
			issue_frame.dispose();
		}
		else if(bb4==a.getSource())
		{
			DeleteMenu dm=new DeleteMenu(menu_frame,pass_frame,str,str1);
			dm.setVisible(true);
			issue_frame.dispose();
		}
		else if(bb6==a.getSource())
		{
			ReturnMenu dm=new ReturnMenu(menu_frame,pass_frame,str,str1);
			dm.setVisible(true);
			issue_frame.dispose();
		}
		else if(bb7==a.getSource())
		{
			Warning dm=new Warning(menu_frame,pass_frame,str,str1);
			dm.setVisible(true);
			issue_frame.dispose();
		}
		else if(b4==a.getSource())
		{
			menu_frame.setVisible(true);
			issue_frame.dispose();
		}
	}
	@Override
	public void run()
	{
		Connection con=null;
		Connectivity cc=null;
		tt=Thread.currentThread();
		while(tt==t0)
		{
			c=Calendar.getInstance();
			l0.setText(c.get(Calendar.HOUR)+":"+c.get(Calendar.MINUTE)+":"+c.get(Calendar.SECOND));
			try
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		if(thread==Thread.currentThread())
		{
			menu_frame.setVisible(true);
			issue_frame.dispose();
		}
		if(Thread.currentThread()==thread1)
		{
			try
			{
				cc=new Connectivity();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			con=cc.getConn();
			check=0;
			try
			{				
				PreparedStatement pstmt=con.prepareStatement("select * from book where q < 10");
				ResultSet rs=pstmt.executeQuery();
				while(rs.next())
				{
					bb7.setForeground(Color.RED);
					check=1;
				}
				if(check==0)
					bb7.setEnabled(false);
				else
					bb7.setEnabled(true);
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
	}
}