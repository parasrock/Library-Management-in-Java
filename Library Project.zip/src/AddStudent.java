import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import javax.swing.*;

public class AddStudent extends JFrame implements ActionListener,Runnable
{	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel label1,label2,label3,label4,label5,label6,label7,label8,label9,label10,label11,label12,label13;
	JTextField textfield1,textfield2,textfield3,textfield4,textfield5,textfield6,textfield7;
	JPasswordField passwordfield;
	JComboBox<String> c;
	JButton button1,button2,button3;
	int pp,f;
	final static int skip=20;
	Thread thread;
	JFrame pass_frame;
	public AddStudent(JFrame pass_frame)
	{				
		setLayout(null);
		setBounds(300,90,900,400);
		label1=new JLabel("Add Student");
		this.pass_frame=pass_frame;
		label1.setFont(new Font(getName(),Font.ITALIC,20));
		label1.setBounds(30, 10, 300, 30);
		add(label1);
		label2=new JLabel("Student ID");
		label2.setBounds(50,50, 150, 20);
		add(label2);
		textfield1=new JTextField();
		textfield1.setBounds(220,50, 150, 20);
		add(textfield1);
		label3=new JLabel("Student Name");
		label3.setBounds(500,50, 150, 20);
		add(label3);
		textfield2=new JTextField();
		textfield2.setBounds(620,50, 150, 20);
		add(textfield2);
		label4=new JLabel("Section");
		label4.setBounds(50, 90, 150, 20);
		add(label4);
		textfield3=new JTextField();
		textfield3.setBounds(220, 90, 150, 20);
		add(textfield3);
		label5=new JLabel("Branch");
		label5.setBounds(500, 90, 150, 20);
		add(label5);
		textfield4=new JTextField();		
		textfield4.setBounds(620, 90, 150, 20);
		add(textfield4);
		label6=new JLabel("Phone no");
		label6.setBounds(50, 130, 150, 20);
		add(label6);		
		textfield5=new JTextField();
		textfield5.setBounds(220, 130, 150, 20);
		add(textfield5);
		label7=new JLabel("Address");
		label7.setBounds(500, 130, 150, 20);
		add(label7);
		textfield6=new JTextField();
		textfield6.setBounds(620, 130, 150, 20);
		add(textfield6);
		label8=new JLabel("Password");	
		label8.setBounds(50, 170, 150, 20);
		add(label8);
		passwordfield=new JPasswordField();
		passwordfield.setBounds(220, 170, 150, 20);
		add(passwordfield);
		label9=new JLabel("");
		label9.setBounds(220, 195, 150, 20);
		add(label9);
		passwordfield.addKeyListener(new KeyAdapter() {
			@SuppressWarnings("deprecation")
			public void keyTyped(KeyEvent ke)
			{
				label9.setText("");			
				if(passwordfield.getText().length()>6 && passwordfield.getText().length()<20)
				{
					f=1;
					if(passwordfield.getText().length()<12)
					{
						label9.setText("Weak Password");
						label9.setForeground(Color.pink);
					}
					else if(passwordfield.getText().length()<16)
					{
						label9.setText("Medium Password");
						label9.setForeground(Color.yellow);
					}
					else
					{
						label10.setText("Strong Password");
						label10.setForeground(Color.green);
					}
				}
			}
		});		
		label11=new JLabel("");
		label11.setBounds(220,195, 100, 20);
		label12=new JLabel("Choose any question");
		label12.setBounds(50, 230, 200, 20);
		add(label12);
		c=new JComboBox<String>();
		c.setBounds(220, 230, 250, 20);
		add(c);
		c.addItem("What is your favourite Movie");
		c.addItem("What is your favourite TV chennel");
		c.addItem("What is your NickName");
		c.addItem("What is your favourite Book");
		c.addItem("What is your favourite song");
		label13=new JLabel("Answer");
		label13.setBounds(500, 230, 150, 20);
		add(label13);
		textfield7=new JTextField();
		textfield7.setBounds(620, 230, 150, 20);
		add(textfield7);
		button1=new JButton("Add");
		button1.setBounds(320, 300, 100, 25);
		add(button1);
		button2=new JButton("Cancel");
		button2.setBounds(500,300, 100, 25);
		add(button2);
		button1.addActionListener(this);
		button2.addActionListener(this);
		addWindowListener(new WindowAdapter() { public void windowClosing(WindowEvent we)
		{
			dispose();
		}
		});		
		setFocusable(true);
		thread=new Thread(this);
		addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent arg0) {}
			@Override
			public void keyReleased(KeyEvent arg0) {}
			@Override
			public void keyPressed(KeyEvent arg0) {
				if(arg0.getKeyChar()==KeyEvent.VK_ESCAPE)
				{
					thread.start();
				}
			}
		});
	}

	@SuppressWarnings("deprecation")
	@Override
	public void actionPerformed(ActionEvent a) 
	{
		Connectivity cc=null;
		Connection con=null;
		int fa=0,fn=0,fs=0;		
		if(button1==a.getSource())
		{	
			try
			{
				cc=new Connectivity();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}
			con=cc.getConn();			
			PreparedStatement pstmt1,pstmt2;
			try
			{
				pstmt1=con.prepareStatement("insert into student values(?,?,?,?,?,?,?,?,?,?)");
				pstmt2=con.prepareStatement("insert into backup_student values(?,?,?,?,?,?,?,?,?,?)");
				pstmt1.setString(1, textfield1.getText());
				pstmt1.setString(2, textfield2.getText());
				pstmt1.setString(3, textfield3.getText());
				pstmt1.setString(4, textfield4.getText());
				pstmt1.setString(5, textfield5.getText());
				pstmt1.setString(6, passwordfield.getText());
				pstmt1.setString(7, (String)c.getSelectedItem());
				pstmt1.setString(8, textfield7.getText());
				pstmt1.setString(9, textfield6.getText());
				pstmt1.setInt(10, 0);
				pstmt2.setString(1, textfield1.getText());
				pstmt2.setString(2, textfield2.getText());
				pstmt2.setString(3, textfield3.getText());
				pstmt2.setString(4, textfield4.getText());
				pstmt2.setString(5, textfield5.getText());
				pstmt2.setString(6, passwordfield.getText());
				pstmt2.setString(7, (String)c.getSelectedItem());
				pstmt2.setString(8, textfield7.getText());
				pstmt2.setString(9, textfield6.getText());
				pstmt2.setInt(10, 0);
				if(passwordfield.getText().length()>8 && passwordfield.getText().length()<20)
				{
					for(int i=0;i<passwordfield.getText().length();i++)
					{
						if(passwordfield.getText().charAt(i)>'A' && passwordfield.getText().charAt(i)<'Z')
						{
							fa=1;
							continue;
						}
						if(passwordfield.getText().charAt(i)>'0' && passwordfield.getText().charAt(i)<'9')
						{
							fn=1;
							continue;
						}
						if(!(passwordfield.getText().charAt(i)>'0' && passwordfield.getText().charAt(i)<'9') && !(passwordfield.getText().charAt(i)>'A' && passwordfield.getText().charAt(i)<'Z') && !(passwordfield.getText().charAt(i)>'a' && passwordfield.getText().charAt(i)<'z'))
						{
							fs=1;
							continue;
						}
					}
				}
				if((fa==1) && (fn==1) && (fs==1))
				{
					dispose();
					String str=textfield1.getText();
					String str1=passwordfield.getText();
					int res=JOptionPane.showConfirmDialog(button1,"Do you want to register","Registration",JOptionPane.YES_NO_OPTION);
					if(res==JOptionPane.YES_OPTION)
					{
						pstmt1.executeUpdate();
						pstmt2.executeUpdate();
						textfield1.setText("");
						textfield2.setText("");
						textfield3.setText("");
						textfield4.setText("");
						passwordfield.setText("");
						c.removeAllItems();						
						textfield5.setText("");
						textfield6.setText("");
						textfield7.setText("");
						Menu m=new Menu(pass_frame,2,str,str1);						
						m.setVisible(true);
						pass_frame.dispose();
						dispose();
					}
					else
					{
						pass_frame.setVisible(true);
					}
				}
				else if((fa==1) && (fn==1) && (fs==0))
				{
					JOptionPane.showMessageDialog(button1,"There should be atleast 1 Symbol");
					passwordfield.setText("");
				}
				else if((fa==1) && (fn==0) && (fs==1))
				{
					JOptionPane.showMessageDialog(button1,"There should be atleast 1 Numeric");
					passwordfield.setText("");
				}
				else if((fa==0) && (fn==1) && (fs==1))
				{
					JOptionPane.showMessageDialog(button1,"There should be atleast 1 Upper case");
					passwordfield.setText("");
				}
				else if((fa==1) && (fn==0) && (fs==0))
				{
					JOptionPane.showMessageDialog(button1,"There should be atleast 1 Symbol & Numeric");
					passwordfield.setText("");
				}
				else if((fa==0) && (fn==1) && (fs==0))
				{
					JOptionPane.showMessageDialog(button1,"There should be atleast 1 Symbol & Upper case");
					passwordfield.setText("");
				}
				else if((fa==0) && (fn==0) && (fs==1))
				{
					JOptionPane.showMessageDialog(button1,"There should be atleast 1 Upper case & Numeric");
					passwordfield.setText("");
				}
				else if((fa==0) && (fn==0) && (fs==0))
				{
					JOptionPane.showMessageDialog(button1,"There should be atleast 1 Symbol,Numeric,Upper case");
					passwordfield.setText("");
				}				
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			setFocusable(true);
		}
		else if(button2==a.getSource())
		{			
			dispose();
			pass_frame.setEnabled(true);
		}
	}
	public void run()
	{
		if(thread==Thread.currentThread())
		{
			dispose();
			pass_frame.setEnabled(true);
		}
	}
}