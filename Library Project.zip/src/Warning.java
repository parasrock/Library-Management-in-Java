import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.net.Inet4Address;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JToolBar;
import javax.swing.table.DefaultTableModel;

public class Warning extends JFrame implements Runnable,ActionListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Thread t1,t2;
	JLabel l,ll;
	JFrame menu_frame,pass_frame;
	int i,xx=1;
	JToolBar tb;
	Calendar c;
	JButton bb1,bb2,bb3,bb4,bb5,bb6,bb7;
	Connectivity cc;
	Connection con;
	String str,str1;
	JMenuBar menubar;
	JMenu menu1,menu2,menu3,menu4;
	JMenuItem m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11;
	MenuPanel mp;
	DefaultTableModel dtm;
	public Warning(final JFrame menu_frame,final JFrame pass_frame,String str,String str1) {
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setLayout(null);
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;
		this.str=str;
		this.str1=str1;		
		menubar=new JMenuBar();
		menu1=new JMenu("Books");		
		menu3=new JMenu("ID");
		menu4=new JMenu("Others");
		setJMenuBar(menubar);
		menubar.add(menu1);		
		if(xx==1)
		{
			m1=new JMenuItem("Add Books");
			menu1.add(m1);
			m1.addActionListener(this);
			menu1.addSeparator();			
		}
		m2=new JMenuItem("Show Books");
		menu1.add(m2);		
		m2.addActionListener(this);
		menu1.addSeparator();
		m3=new JMenuItem("Search Books");
		menu1.add(m3);
		m3.addActionListener(this);
		menu1.addSeparator();
		if(xx==1)
		{
			m4=new JMenuItem("Delete Book");
			menu1.add(m4);
			m4.addActionListener(this);
			menu2=new JMenu("Students");
			menubar.add(menu2);
			m5=new JMenuItem("Issue Books");
			menu2.add(m5);
			m5.addActionListener(this);
			menu2.addSeparator();
			m6=new JMenuItem("Return Books");
			menu2.add(m6);			
			m6.addActionListener(this);
		}
		menubar.add(menu3);
		menubar.add(menu4);
		m7=new JMenuItem("View Profile");
		menu3.add(m7);
		m7.addActionListener(this);
		menu3.addSeparator();
		m8=new JMenuItem("Change Password");
		menu3.add(m8);
		m8.addActionListener(this);		
		menu3.addSeparator();
		m9=new JMenuItem("Log out");
		menu3.add(m9);
		m9.addActionListener(this);
		m10=new JMenuItem("Help");
		menu4.add(m10);
		m10.addActionListener(this);
		menu4.addSeparator();
		m11=new JMenuItem("Exit");
		menu4.add(m11);
		m11.addActionListener(this);
		tb=new JToolBar();
		tb.setBounds(0,0,getToolkit().getScreenSize().width,40);
		add(tb);
		if(xx==1)
		{
			bb1=new JButton(new ImageIcon("add.jpg"));
			bb1.setToolTipText("Add Books");
			tb.add(bb1);
			bb1.addActionListener(this);
		}
		bb2=new JButton(new ImageIcon("view.jpg"));
		tb.add(bb2);
		tb.setBounds(0,0,getToolkit().getScreenSize().width,40);
		add(tb);		
		bb2.setToolTipText("Show Books");				
		bb3=new JButton(new ImageIcon("search.jpg"));
		bb3.setToolTipText("Search Books");
		bb3.addActionListener(this);
		tb.add(bb3);		
		if(xx==1)
		{
			bb4=new JButton(new ImageIcon("delete.jpg"));
			bb4.setToolTipText("Delete Books");
			bb4.addActionListener(this);
			tb.add(bb4);
			bb5=new JButton(new ImageIcon("issuebook.jpg"));
			bb5.setToolTipText("Issue Menu");
			tb.add(bb5);
			bb5.addActionListener(this);
			bb6=new JButton(new ImageIcon("returnBook.jpg"));
			bb6.setToolTipText("Return Books");
			tb.add(bb6);
			bb6.addActionListener(this);
		}
		bb2.addActionListener(this);
		ll=new JLabel(new ImageIcon("back.jpg"));
		ll.setBounds(1270, 50, 35, 35);
		add(ll);		
		ll.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent arg0){}
			@Override
			public void mousePressed(MouseEvent arg0){}
			@Override
			public void mouseExited(MouseEvent arg0){}
			@Override
			public void mouseEntered(MouseEvent arg0){}
			@Override
			public void mouseClicked(MouseEvent arg0)
			{
				menu_frame.setVisible(true);
				dispose();
			}
		});
		l=new JLabel();
		l.setFont(new Font(getName(),Font.BOLD,20));
		l.setBounds(0,50,800, 50);
		try{
			cc=new Connectivity();
		}
		catch(IOException e){
			e.printStackTrace();		
		}
		con=cc.getConn();
		String data[]=new String[7];
		String strr[]={"Book ID","Book Name","Author Name","Category","Sale Price","Purchase Price","Quantity"};
		dtm=new DefaultTableModel(null,strr);
		try{
			PreparedStatement pstmt=con.prepareStatement("select * from book where q < 10");
			ResultSet rs=pstmt.executeQuery();			
			while(rs.next())
			{
				data[0]=String.valueOf(rs.getInt("id"));
				data[1]=rs.getString("bn");
				data[2]=rs.getString("an");
				data[3]=rs.getString("cat");
				data[4]=String.valueOf(rs.getInt("sp"));
				data[5]=String.valueOf(rs.getInt("pp"));
				data[6]=String.valueOf(rs.getInt("q"));
				dtm.addRow(data);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();			
		}
		JTable table=new JTable(dtm);
		JScrollPane sp=new JScrollPane(table);
		sp.setBounds(100, 150, getToolkit().getScreenSize().width-200,400);
		add(sp);
		t1=new Thread(this);		
		t1.start();
		t2=new Thread(this);
		t2.start();
		add(l);						
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	@Override
	public void run() {
		do
		{			
				try{
					PreparedStatement pstmt=con.prepareStatement("select * from book where q < 10");			
					ResultSet rs=pstmt.executeQuery();
					while(rs.next())
					{
						l.setText(rs.getString("bn")+" is Low in Stock");
						i=0;
						while(i<getToolkit().getScreenSize().width)
						{
							l.setBounds(i,50,800,40);
							i+=5;
							try{
								Thread.sleep(40);
							}
							catch(InterruptedException ee)
							{
								ee.printStackTrace();
							}
						}
					}
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
		}while(t1==Thread.currentThread());		
	}
	@Override
	public void actionPerformed(ActionEvent a) {
		if(m1==a.getSource())
		{
			AddMenu am=new AddMenu(menu_frame, pass_frame, str, str1);
			am.setVisible(true);
			dispose();
		}
		else if(m2==a.getSource())
		{
			ShowMenu sm=new ShowMenu(menu_frame, pass_frame, 1, str, str1);
			sm.setVisible(true);
			dispose();
		}
		else if(m3==a.getSource())
		{
			SearchMenu sm=new SearchMenu(menu_frame, pass_frame, 1, str, str1);
			sm.setVisible(true);
			dispose();
		}
		else if(m4==a.getSource())
		{
			DeleteMenu dm=new DeleteMenu(menu_frame, pass_frame, str, str1);
			dm.setVisible(true);
			dispose();
		}
		else if(m5==a.getSource())
		{
			IssueMenu im=new IssueMenu(menu_frame, pass_frame, str, str1);
			im.setVisible(true);
			dispose();
		}
		else if(m6==a.getSource())
		{
			ReturnMenu rm=new ReturnMenu(menu_frame, pass_frame, str, str1);
			rm.setVisible(true);
			dispose();
		}
		else if(m7==a.getSource())
		{
			LibrarienDetails lb=new LibrarienDetails(this, str, str1);
			lb.setVisible(true);
			setEnabled(false);
		}
		else if(m8==a.getSource())
		{
			ChangePassword cp=new ChangePassword(this,1,str);
			cp.setVisible(true);
			setEnabled(false);
		}
		else if(m9==a.getSource())
		{
			try{
				cc=new Connectivity();
			}
			catch(IOException e){
				e.printStackTrace();
			}
			con=cc.getConn();
			try{
				PreparedStatement pstmt=con.prepareStatement("delete from session where ip=?");
				pstmt.setString(1,Inet4Address.getLocalHost().getHostAddress());
				pstmt.executeUpdate();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}						
			pass_frame.setVisible(true);
			dispose();
		}
		else if(m11==a.getSource())
		{
			int res=JOptionPane.showConfirmDialog(m11,"Do you want to exit","Exit",JOptionPane.YES_NO_OPTION);
			if(res==JOptionPane.YES_OPTION)
				System.exit(0);
		}
		else if(bb1==a.getSource())
		{
			AddMenu am=new AddMenu(menu_frame, pass_frame, str, str1);
			am.setVisible(true);
			dispose();
		}
		else if(bb2==a.getSource())
		{
			ShowMenu sm=new ShowMenu(menu_frame, pass_frame, 1, str, str1);
			sm.setVisible(true);
			dispose();
		}
		else if(bb3==a.getSource())
		{
			SearchMenu sm=new SearchMenu(menu_frame, pass_frame, 1, str, str1);
			sm.setVisible(true);
			dispose();
		}
		else if(bb4==a.getSource())
		{
			DeleteMenu dm=new DeleteMenu(menu_frame, pass_frame, str, str1);
			dm.setVisible(true);
			dispose();
		}
		else if(bb5==a.getSource())
		{
			IssueMenu im=new IssueMenu(menu_frame, pass_frame, str, str1);
			im.setVisible(true);
			dispose();
		}
		else if(bb6==a.getSource())
		{
			ReturnMenu rm=new ReturnMenu(menu_frame, pass_frame, str, str1);
			rm.setVisible(true);
			dispose();
		}		
	}
}