import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import java.sql.*;
import java.util.Calendar;

import javax.swing.*;

public class MenuPanel extends JPanel implements ActionListener,Runnable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel l,ll,l0,lb;
	JFrame menu_frame,pass_frame;
	JToolBar tb;
	JButton bb1,bb2,bb3,bb4,bb5,bb6,bb7;
	int xx,count,check;
	Connectivity cc;
	Connection con;
	Calendar c;
	JPanel o;
	JTextArea ta;
	Thread t,tt;
	String str,str1;
	public MenuPanel(final JFrame menu_frame,final JFrame pass_frame,int x,String str,String str1)
	{
		setLayout(null);		
		setSize(getToolkit().getScreenSize());
		tb=new JToolBar();
		t=new Thread(this);
		xx=1;
		xx=x;
		o=this;
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;
		this.str=str;
		this.str1=str1;
		ta=new JTextArea(5,20);
		lb=new JLabel(new ImageIcon("back.jpg"));
		lb.setBounds(getToolkit().getScreenSize().width-50,45, 50, 40);
		add(lb);
		lb.addMouseListener(new MouseListener(){
			@Override
			public void mouseReleased(MouseEvent arg0){}
			@Override
			public void mousePressed(MouseEvent arg0){}
			@Override
			public void mouseExited(MouseEvent arg0){}
			@Override
			public void mouseEntered(MouseEvent arg0){}
			@Override
			public void mouseClicked(MouseEvent arg0)
			{				
				pass_frame.setVisible(true);
				menu_frame.dispose();
			}
		});
		l0=new JLabel("");
		l0.setBounds(getToolkit().getScreenSize().width-150,45,100,30);
		l0.setFont(new Font(getName(), Font.BOLD, 20));
		add(l0);
		t=new Thread(this);
		t.start();
		ll=new JLabel(new ImageIcon("library.jpg"));
		ll.setBounds(0,140,getToolkit().getScreenSize().width,(int)getToolkit().getScreenSize().height);
		add(ll);
		if(xx==1)
		{
			bb1=new JButton(new ImageIcon("add.jpg"));
			bb1.setToolTipText("Add Books");
			tb.add(bb1);
			bb1.addActionListener(this);
		}
		bb2=new JButton(new ImageIcon("view.jpg"));
		tb.add(bb2);
		tb.setBounds(0,0,getToolkit().getScreenSize().width,40);
		add(tb);		
		bb2.setToolTipText("Show Books");		
		l=new JLabel("WelCome to Library ManageMent System");
		l.setFont(new Font(getName(),Font.ITALIC,50));
		l.setBounds(200,30, 1000, 100);
		bb3=new JButton(new ImageIcon("search.jpg"));
		bb3.setToolTipText("Search Books");
		bb3.addActionListener(this);
		tb.add(bb3);		
		if(xx==1)
		{
			bb4=new JButton(new ImageIcon("delete.jpg"));
			bb4.setToolTipText("Delete Books");
			bb4.addActionListener(this);
			tb.add(bb4);
			bb5=new JButton(new ImageIcon("issuebook.jpg"));
			bb5.setToolTipText("Issue Menu");
			tb.add(bb5);
			bb5.addActionListener(this);
			bb6=new JButton(new ImageIcon("returnBook.jpg"));
			bb6.setToolTipText("Return Books");
			tb.add(bb6);
			bb6.addActionListener(this);
			bb7=new JButton("Warning");
			tb.add(bb7);
			bb7.addActionListener(this);
		}
		add(l);		
		bb2.addActionListener(this);				
		tt=new Thread(this);
		tt.start();			
	}
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(bb1==e.getSource())
		{
			AddMenu am=new AddMenu(menu_frame,pass_frame,str,str1);
			am.setVisible(true);
			menu_frame.dispose();
		}
		else if(bb2==e.getSource())
		{
			ShowMenu am=new ShowMenu(menu_frame,pass_frame,xx,str,str1);
			am.setVisible(true);
			menu_frame.dispose();
		}
		else if(bb3==e.getSource())
		{
			SearchMenu sm=new SearchMenu(menu_frame,pass_frame,xx,str,str1);
			sm.setVisible(true);
			menu_frame.dispose();
		}
		else if(bb4==e.getSource())
		{
			DeleteMenu dm=new DeleteMenu(menu_frame,pass_frame,str,str1);
			dm.setVisible(true);
			menu_frame.dispose();
		}				
		else if(bb5==e.getSource())
		{
			IssueMenu im=new IssueMenu(menu_frame,pass_frame,str,str1);
			im.setVisible(true);
			menu_frame.dispose();
		}
		else if(bb6==e.getSource())
		{
			ReturnMenu im=new ReturnMenu(menu_frame,pass_frame, str, str1);
			im.setVisible(true);
			menu_frame.dispose();
		}
		else if(bb7==e.getSource())
		{
			Warning w=new Warning(menu_frame,pass_frame,str,str1);
			w.setVisible(true);
			menu_frame.dispose();
		}
	}
	@Override	
	public void run()
	{			
		while(Thread.currentThread()==t)
		{
			c=Calendar.getInstance();
			l0.setText(c.get(Calendar.HOUR)+":"+c.get(Calendar.MINUTE)+":"+c.get(Calendar.SECOND));			
			try
			{
				Thread.sleep(1000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		if(Thread.currentThread()==tt && xx==1)
		{
			try
			{
				cc=new Connectivity();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			con=cc.getConn();
			check=0;
			try
			{				
				PreparedStatement pstmt=con.prepareStatement("select * from book where q < 10");
				ResultSet rs=pstmt.executeQuery();
				while(rs.next())
				{
					bb7.setForeground(Color.RED);
					check=1;
				}
				if(check==0)
					bb7.setEnabled(false);
				else
					bb7.setEnabled(true);
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}				
	}	
}