import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import java.io.IOException;
import java.sql.*;
import java.util.Calendar;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ReturnPanel extends JPanel implements ActionListener,Runnable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel l1,l2,l5,l;
	JTextField t1;
	JButton b1,b2,b4,bb1,bb2,bb3,bb4,bb5,bb6;	
	JFrame return_frame,menu_frame,pass_frame;
	String str2,str3;
	String time,strr;
	int index,check;
	JTable table;
	JToolBar tb;
	Connectivity cc;
	Connection con;
	DefaultTableModel dtm;
	Calendar c;
	Thread thread,tt;
	int y,row,ppp;
	int pp;
	String str[]={"Book ID","Book Name","Author Name","Price","Book Issued","remainin days","Fine"};
	public ReturnPanel(final JFrame return_Frame,final JFrame menu_frame,final JFrame pass_frame,final String str2,final String str3)
	{				
		setLayout(null);
		setSize(getToolkit().getScreenSize());
		c=Calendar.getInstance();
		this.return_frame=return_Frame;
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;		
		this.str2=str2;
		this.str3=str3;
		tb=new JToolBar();
		bb1=new JButton(new ImageIcon("add.jpg"));
		bb1.setToolTipText("Add Books");
		tb.add(bb1);
		bb1.addActionListener(this);
		bb2=new JButton(new ImageIcon("view.jpg"));
		tb.add(bb2);
		dtm=new DefaultTableModel(null,str);
		table=new JTable(dtm);
		JScrollPane sp=new JScrollPane(table);
		add(sp);
		sp.setBounds(200,220,1000,200);
		tb.setBounds(0,0,getToolkit().getScreenSize().width,40);
		add(tb);		
		bb2.setToolTipText("Show Books");				
		bb3=new JButton(new ImageIcon("search.jpg"));
		bb3.setToolTipText("Search Books");
		bb3.addActionListener(this);
		tb.add(bb3);
		bb4=new JButton(new ImageIcon("delete.jpg"));
		bb4.setToolTipText("Delete Books");
		bb4.addActionListener(this);
		tb.add(bb4);
		bb5=new JButton(new ImageIcon("issuebook.jpg"));
		bb5.setToolTipText("Issue Menu");
		tb.add(bb5);
		bb5.addActionListener(this);
		bb6=new JButton("Warning");
		tb.add(bb6);
		bb6.addActionListener(this);
		bb2.addActionListener(this);
		l1=new JLabel("Return Book Menu");
		l1.setFont(new Font(getName(),Font.BOLD,20));
		l1.setBounds(100, 60, 200, 30);
		add(l1);
		l2=new JLabel("Student ID");
		l2.setBounds(500,150,100,20);
		add(l2);
		l5=new JLabel();
		l5.setFont(new Font(getName(),Font.BOLD,30));
		l5.setBounds(550,600,250,40);
		add(l5);
		t1=new JTextField();
		t1.setBounds(650, 150, 100, 20);
		add(t1);
		b1=new JButton("Show");
		b1.setBounds(800, 150, 100, 20);
		add(b1);b4.setEnabled(false);
		b1.addActionListener(this);
		b2=new JButton("Return Book");
		b2.setBounds(480, 500, 120, 20);		
		add(b2);
		b2.setEnabled(false);
		b2.addActionListener(this);			
		b4=new JButton("Lost Book");
		b4.setBounds(720, 500, 100, 20);
		
		add(b4);		
		b4.addActionListener(this);
		thread=new Thread(this);
		setFocusable(true);
		addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent arg0) {}
			@Override
			public void keyReleased(KeyEvent arg0) {}
			@Override
			public void keyPressed(KeyEvent a) {
				if(a.getKeyChar()==KeyEvent.VK_ESCAPE)
				{
					thread.start();
				}
			}
		});
		l=new JLabel(new ImageIcon("back.jpg"));
		l.setBounds(getToolkit().getScreenSize().width-100,45, 50, 40);
		add(l);
		l.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent arg0) {}
			@Override
			public void mousePressed(MouseEvent arg0) {}
			@Override
			public void mouseExited(MouseEvent arg0) {}
			@Override
			public void mouseEntered(MouseEvent arg0) {}
			@Override
			public void mouseClicked(MouseEvent arg0)
			{
				t1.setText("");
				while(dtm.getRowCount()!=0)
					dtm.removeRow(0);
				b2.setEnabled(false);
				menu_frame.setVisible(true);
				return_Frame.dispose();
			}
		});
		tt=new Thread(this);
		tt.start();
	}
	@Override
	public void actionPerformed(ActionEvent a)
	{
		Connectivity cc=null;
		Connection con=null;
		int f=0;							
		int xxx=0;
		if(b1==a.getSource())
		{			
			try
			{
				cc=new Connectivity();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
			con=cc.getConn();
			int size=0;
			try
			{
				PreparedStatement pstmt=con.prepareStatement("select * from transaction where sid=? and return_date=?");
				pstmt.setString(1,t1.getText());
				pstmt.setString(2,"");
				ResultSet rs=pstmt.executeQuery();
				while(rs.next()){
					f=1;
					size++;
				}		
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			if(f==1)
			{
				while(dtm.getRowCount()!=0)
					dtm.removeRow(0);
				String str1[]=new String[7];		
				final String st[]=new String[size];
				int i=0;
				try
				{				
					PreparedStatement pstmt1;
					ResultSet rs1;
					PreparedStatement pstmt=con.prepareStatement("select bid,book_issued,issued_date,issued_time,DATEDIFF(CURDATE(),issued_date) from transaction where sid=? and return_date=?");
					pstmt.setString(1,t1.getText());
					pstmt.setString(2,"");
					ResultSet rs=pstmt.executeQuery();
					while(rs.next())
					{
						pstmt1=con.prepareStatement("select * from book where id=?");
						pstmt1.setInt(1,rs.getInt(1));
						rs1=pstmt1.executeQuery();					
						while(rs1.next())
						{
							str1[0]=String.valueOf(rs1.getInt("id"));
							str1[1]=rs1.getString("bn");
							str1[2]=rs1.getString("an");
							str1[3]=(String.valueOf(rs1.getInt("sp")));
							str1[4]=(String.valueOf(rs.getInt(2)));
							strr=rs.getString(3);
							st[i]=rs.getString(4);
							y=rs.getInt(5);
							if(y>=15)
								str1[5]=String.valueOf(0);
							else
								str1[5]=(String.valueOf(15-y));
							if(y>15)
								str1[6]=String.valueOf(rs.getInt("book_issued")*y);
							else
								str1[6]=String.valueOf(0);
							i++;
							dtm.addRow(str1);
						}					
					}			
				}		
				catch(SQLException e)
				{
					e.printStackTrace();
				}															
				table.addMouseListener(new MouseListener()
				{
					@Override
					public void mouseReleased(MouseEvent arg0){}
					@Override
					public void mousePressed(MouseEvent arg0){}
					@Override
					public void mouseExited(MouseEvent arg0){}
					@Override
					public void mouseEntered(MouseEvent arg0){}
					@Override
					public void mouseClicked(MouseEvent arg0)
					{					
						pp=1;
						row=table.getSelectedRow();
						time=st[row];
						index=Integer.parseInt((String)table.getModel().getValueAt(table.getSelectedRow(),0));
						l5.setText("Your fine is : "+(String)dtm.getValueAt(row,6));
						b2.setEnabled(true);
						b4.setEnabled(true);
					}				
				});
				setFocusable(true);
			}
			else
				JOptionPane.showMessageDialog(b1,"You have not issue any Book","Book InFo",JOptionPane.INFORMATION_MESSAGE);
		}
		else if(b2==a.getSource())
		{			
			if(pp!=1)
				JOptionPane.showMessageDialog(b2, "please select any book");
			else
			{
				try
				{
					cc=new Connectivity();
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
				con=cc.getConn();
				try
				{
					PreparedStatement pstmt=con.prepareStatement("select * from transaction where sid=? and bid=? and issued_time=?");
					pstmt.setString(1, t1.getText());					
					pstmt.setInt(2,index);
					pstmt.setString(3, time);
					ResultSet rs=pstmt.executeQuery();
					while(rs.next())
						strr=rs.getString("issued_date");
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
				try
				{
					PreparedStatement pstmt=con.prepareStatement("select * from student where id=?");
					pstmt.setString(1, t1.getText());										
					ResultSet rs=pstmt.executeQuery();
					while(rs.next())
					{
						xxx=Integer.parseInt(rs.getString("ib"));
					}
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
				try
				{
					PreparedStatement pstmt1=con.prepareStatement("select * from book where id=?");
					pstmt1.setInt(1, index);
					ResultSet rs1=pstmt1.executeQuery();
					while(rs1.next())
					{
						ppp=rs1.getInt(6);
					}
				}
				catch(SQLException ee){
					ee.printStackTrace();
				}				
				try
				{
					cc=new Connectivity();
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
				con=cc.getConn();
				try
				{							
					PreparedStatement pstmt=con.prepareStatement("update transaction set return_date=CURDATE() where sid=? and bid=? and issued_time=?");
					PreparedStatement pstmt1=con.prepareStatement("update book set q=? where id=?");
					PreparedStatement pstmt2=con.prepareStatement("update student set ib=? where id=?");
					PreparedStatement pstmt3=con.prepareStatement("update backup_student set ib=? where id=?");
					pstmt.setString(1,t1.getText());
					pstmt.setInt(2,index);
					pstmt.setString(3,time);
					pstmt1.setInt(1,(ppp+1));
					pstmt1.setInt(2,index);
					pstmt2.setInt(1,xxx-1);
					pstmt2.setString(2, t1.getText());
					pstmt3.setInt(1,xxx-1);
					pstmt3.setString(2, t1.getText());							
					int res=JOptionPane.showConfirmDialog(b2,"Do you want to return the Book","Return Book Menu",JOptionPane.YES_NO_OPTION);
					if(res==JOptionPane.YES_OPTION)
					{
						pstmt.executeUpdate();
						pstmt1.executeUpdate();
						pstmt2.executeUpdate();
						pstmt3.executeUpdate();
						dtm.removeRow(table.getSelectedRow());
						l5.setText("");
						JOptionPane.showMessageDialog(b2, "Successfully Submitted");																
					}
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}			
		}		
		else if(b4==a.getSource())
		{
			int res;
			if(pp!=1)
				JOptionPane.showMessageDialog(b4,"Please select any book","",JOptionPane.ERROR_MESSAGE);
			else
			{
				int sprice=0;
				try
				{
					cc=new Connectivity();
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
				con=cc.getConn();
				try
				{
					PreparedStatement pstmt=con.prepareStatement("delete from transaction where sid=? and bid=? and issued_time=?");
					PreparedStatement pstmt1=con.prepareStatement("update student set ib=? where id=?");
					PreparedStatement pstmt2=con.prepareStatement("update backup_student set ib=? where id=?");
					PreparedStatement pstmt3=con.prepareStatement("select sp from book where id=?");
					pstmt.setString(1, t1.getText());
					pstmt.setInt(2, index);
					pstmt.setString(3, time);
					pstmt1.setInt(1, xxx-1);
					pstmt1.setString(2, t1.getText());
					pstmt2.setInt(1, xxx-1);
					pstmt2.setString(2, t1.getText());
					pstmt3.setInt(1, index);
					ResultSet rs=pstmt3.executeQuery();				
					while(rs.next())
						sprice=rs.getInt("sp");
					if(y>15)
						res=JOptionPane.showConfirmDialog(b4,"Have you recieved "+(sprice+y)+" Rupees  ??","Confirmation",JOptionPane.YES_NO_OPTION);
					else
						res=JOptionPane.showConfirmDialog(b4,"Have you recieved "+sprice+" Rupees  ??","Confirmation",JOptionPane.YES_NO_OPTION);
					if(res==JOptionPane.YES_OPTION)
					{
						pstmt.executeUpdate();
						pstmt1.executeUpdate();
						pstmt2.executeUpdate();
						l5.setText("");
						dtm.removeRow(table.getSelectedRow());
					}
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
				setFocusable(true);
			}
		}
		else if(bb1==a.getSource())
		{
			AddMenu am=new AddMenu(menu_frame,pass_frame,str2,str3);
			am.setVisible(true);
			return_frame.dispose();
		}
		else if(bb2==a.getSource())
		{
			ShowMenu am=new ShowMenu(menu_frame,pass_frame,1,str2,str3);
			am.setVisible(true);
			return_frame.dispose();
		}
		else if(bb3==a.getSource())
		{
			SearchMenu sm=new SearchMenu(menu_frame,pass_frame,1,str2,str3);
			sm.setVisible(true);
			return_frame.dispose();
		}
		else if(bb4==a.getSource())
		{
			DeleteMenu dm=new DeleteMenu(menu_frame,pass_frame,str2,str3);
			dm.setVisible(true);
			return_frame.dispose();
		}				
		else if(bb5==a.getSource())
		{
			IssueMenu im=new IssueMenu(menu_frame,pass_frame,str2,str3);
			im.setVisible(true);
			return_frame.dispose();
		}
		else if(bb6==a.getSource())
		{
			Warning im=new Warning(menu_frame,pass_frame,str2,str3);
			im.setVisible(true);
			return_frame.dispose();
		}
	}
	public void run()
	{		
		if(thread==Thread.currentThread())
		{
			menu_frame.setVisible(true);
			return_frame.dispose();
		}
		if(Thread.currentThread()==tt)
		{
			try
			{
				cc=new Connectivity();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			con=cc.getConn();
			check=0;
			try
			{				
				PreparedStatement pstmt=con.prepareStatement("select * from book where q < 10");
				ResultSet rs=pstmt.executeQuery();
				while(rs.next())
				{
					bb6.setForeground(Color.RED);
					check=1;
				}
				if(check==0)
					bb6.setEnabled(false);
				else
					bb6.setEnabled(true);
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		}
	}
}