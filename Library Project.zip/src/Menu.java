import java.awt.event.*;
import java.io.IOException;
import java.net.Inet4Address;
import java.sql.*;

import javax.swing.*;

public class Menu extends JFrame implements ActionListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JMenuBar menubar;
	JMenu menu1,menu2,menu3,menu4;
	JMenuItem m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11;
	MenuPanel mp;
	JFrame current_frame,pass_frame;
	Connectivity cc;
	Connection con;
	static int warn=0;
	int xx;
	String str,str1;
	Thread t;
	public Menu(final JFrame pass_frame,int x,String str,String str1)
	{
		super("Library ManageMant System");
		t=new Thread();
		xx=x;
		setLayout(null);
		this.str=str;
		this.str1=str1;
		current_frame=this;
		this.pass_frame=pass_frame;
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		menubar=new JMenuBar();
		menu1=new JMenu("Books");		
		menu3=new JMenu("ID");
		menu4=new JMenu("Others");
		setJMenuBar(menubar);
		menubar.add(menu1);		
		if(xx==1)
		{
			m1=new JMenuItem("Add Books");
			menu1.add(m1);
			m1.addActionListener(this);
			menu1.addSeparator();			
		}
		m2=new JMenuItem("Show Books");
		menu1.add(m2);		
		m2.addActionListener(this);
		menu1.addSeparator();
		m3=new JMenuItem("Search Books");
		menu1.add(m3);
		m3.addActionListener(this);
		menu1.addSeparator();
		if(xx==1)
		{
			m4=new JMenuItem("Delete Book");
			menu1.add(m4);
			m4.addActionListener(this);
			menu2=new JMenu("Students");
			menubar.add(menu2);
			m5=new JMenuItem("Issue Books");
			menu2.add(m5);
			m5.addActionListener(this);
			menu2.addSeparator();
			m6=new JMenuItem("Return Books");
			menu2.add(m6);			
			m6.addActionListener(this);
		}
		menubar.add(menu3);
		menubar.add(menu4);
		m7=new JMenuItem("View Profile");
		menu3.add(m7);
		m7.addActionListener(this);
		menu3.addSeparator();
		m8=new JMenuItem("Change Password");
		menu3.add(m8);
		m8.addActionListener(this);		
		menu3.addSeparator();
		m9=new JMenuItem("Log out");
		menu3.add(m9);
		m9.addActionListener(this);		
		mp=new MenuPanel(current_frame,pass_frame,xx,str,str1);
		m10=new JMenuItem("Help");
		menu4.add(m10);
		m10.addActionListener(this);
		menu4.addSeparator();
		m11=new JMenuItem("Exit");
		menu4.add(m11);
		m11.addActionListener(this);
		add(mp);
		mp.setBounds(0, 3, getToolkit().getScreenSize().width,getToolkit().getScreenSize().height);
		addWindowListener(new WindowAdapter() { public void windowClosing(WindowEvent we){ 
			System.exit(0);
		} });
		t.start();		
	}
	@Override
	public void actionPerformed(ActionEvent a) 
	{
		if(m1==a.getSource())
		{
			AddMenu am=new AddMenu(current_frame,pass_frame,str,str1);
			am.setVisible(true);
			dispose();
		}
		else if(m2==a.getSource())
		{
			ShowMenu am=new ShowMenu(current_frame,pass_frame,xx,str,str1);
			am.setVisible(true);
			dispose();
		}
		else if(m3==a.getSource())
		{
			SearchMenu am=new SearchMenu(current_frame,pass_frame,xx,str,str1);
			am.setVisible(true);
			dispose();
		}
		else if(m4==a.getSource())
		{
			DeleteMenu dm=new DeleteMenu(current_frame,pass_frame,str,str1);
			dm.setVisible(true);
			dispose();
		}
		else if(m5==a.getSource())
		{
			IssueMenu im=new IssueMenu(current_frame,pass_frame,str,str1);
			im.setVisible(true);
			dispose();
		}
		else if(m6==a.getSource())
		{
			ReturnMenu rm=new ReturnMenu(current_frame,pass_frame,str,str1);
			rm.setVisible(true);
			dispose();
		}
		else if(m7==a.getSource())
		{
			if(xx==1)
			{
				LibrarienDetails lb=new LibrarienDetails(current_frame,str,str1);
				lb.setVisible(true);
				setEnabled(false);
			}
			else if(xx==2)
			{
				StudentDetails sd=new StudentDetails(current_frame, str, str1);
				sd.setVisible(true);
				setEnabled(false);
			}
		}
		else if(m8==a.getSource())
		{				
			ChangePassword cp=new ChangePassword(current_frame,xx,str);
			setEnabled(false);			
			cp.setVisible(true);
		}
		else if(m9==a.getSource())
		{
			try{
				cc=new Connectivity();
			}
			catch(IOException e){
				e.printStackTrace();
			}
			con=cc.getConn();
			try{
				PreparedStatement pstmt=con.prepareStatement("delete from session where ip=?");
				pstmt.setString(1,Inet4Address.getLocalHost().getHostAddress());
				pstmt.executeUpdate();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			pass_frame.setVisible(true);
			dispose();
		}
		else if(m10==a.getSource())
		{
			
		}
		else if(m11==a.getSource())
		{
			int result=JOptionPane.showConfirmDialog(m11,"Choose Yes or NO","Exit",JOptionPane.YES_NO_OPTION);
			dispose();
			if(result == JOptionPane.YES_OPTION)
				System.exit(0);
			else
				setVisible(true);
		}		
	}	
}