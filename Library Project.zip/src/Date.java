import java.util.StringTokenizer;

public class Date
{		
	static public int converter(String str,String str1)
	{
		int a[]=new int[3];
		int b[]=new int[3];
		StringTokenizer st=new StringTokenizer(str,":/.,");
		StringTokenizer st1=new StringTokenizer(str1,":/.,");
		int day=0,i=0;
		while(st.hasMoreTokens())
		{
			a[i]=Integer.parseInt(st.nextToken());
			i++;
		}
		i=0;
		while(st1.hasMoreTokens())
		{
			b[i]=Integer.parseInt(st1.nextToken());
			i++;
		}
		i=0;
		while(b[0]!=a[0])
		{
			if(b[0]>a[0])
			{
				day++;
				b[0]--;
			}
			else
			{
				if(((b[1]%12)==0)||((b[1]%12)==1)||(b[1]==3)||(b[1]==5)||(b[1]==7)||(b[1]==8)||(b[1]==10))
				{
					if((b[1]-1)%12==2)
					{
						if((b[2]%400==0)|| ((b[2]%4==0) && (b[2]%100!=0)))
						{
							day+=b[0];
							b[0]=29;
						}
						else
						{
							day+=b[0];
							b[0]=28;
						}
					}
				}
				else if((b[1]==4)||(b[1]==6)||(b[1]==9)||(b[1]==11))
				{
					day+=b[0];
					b[0]=31;
				}
				else
				{
					if((b[2]%400==0)|| ((b[2]%4==0) && (b[2]%100!=0)))
					{
						day+=b[0];
						b[0]=31;
					}
					else
					{
						day+=b[0];
						b[0]=31;
					}
				}
				b[1]--;
			}
		}
		while(b[1]!=a[1])
		{
			if(b[1]>a[1])
			{
				if(((b[1]%12)==0)||((b[1]%12)==1)||((b[1]%12)==3)||((b[1]%12)==5)||((b[1]%12)==7)||((b[1]%12)==8)||((b[1]%12)==10))
					day+=31;
				else if(((b[1]%12)==4)||((b[1]%12)==6)||((b[1]%12)==9)||((b[1]%12)==11))
					day+=30;
				else
				{
					if((b[2]%400==0)|| ((b[2]%4==0) || (b[2]%100!=0)))
						day+=29;
					else
						day+=28;
				}
				b[1]--;
			}
			else
			{
				b[1]+=12;
				b[2]--;
			}
		}
		while(b[2]!=a[2])
		{
			if(b[2]>a[2])
			{
				if((b[2]%400==0)|| ((b[2]%4==0) || (b[2]%100!=0)))
					day+=366;
				else
					day+=365;
			}
			b[2]--;
		}		
		return day;
	}	
}