import java.awt.Font;
import java.awt.event.*;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.TreeSet;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class DeleteBook extends JPanel implements ActionListener
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton button1,button2,button3;
	JFrame delete_frame,menu_frame;
	JLabel label1,label2,label3;
	int f=0,attemp=0,size;
	String s="";
	JComboBox<String> c;
	Connectivity connect_to_db;	
	Connection connection;
	DefaultTableModel defaulttablemodel;
	TreeSet<String> ts;
	JTable table;
	JScrollPane sp;
	ArrayList<Integer> al;
	LinkedList<Integer> ll;
	String id,pass;
	public DeleteBook(final JFrame delete_frame,final JFrame menu_frame,String id,String pass)
	{
		String title[]={"Book ID","Book Name","Author Name","Sale Price","Purchase Price","Quaantity"};
		setLayout(null);
		button1=new JButton("clear");
		button1.setBounds(720, 100, 100, 20);
		add(button1);
		al=new ArrayList<Integer>();
		button1.addActionListener(this);
		this.delete_frame=delete_frame;
		this.menu_frame=menu_frame;
		this.id=id;
		this.pass=pass;
		label1=new JLabel("Delete All Books of the Name");
		label1.setFont(new Font(getName(),Font.ITALIC,20));
		label1.setBounds(50, 30, 400, 30);
		add(label1);
		label2=new JLabel("Book Name");
		label2.setBounds(250,100,120,20);
		add(label2);
		button2=new JButton("Show");
		button2.setBounds(600, 100, 100, 20);
		add(button2);
		ll=new LinkedList<Integer>();
		ts=new TreeSet<String>();
		button2.addActionListener(this);
		label3=new JLabel(new ImageIcon("back.jpg"));
		label3.setBounds(1270, 10, 35, 35);
		add(label3);
		label3.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent arg0){}
			@Override
			public void mousePressed(MouseEvent arg0){}
			@Override
			public void mouseExited(MouseEvent arg0){}
			@Override
			public void mouseEntered(MouseEvent arg0){}
			@Override
			public void mouseClicked(MouseEvent arg0)
			{
				menu_frame.setVisible(true);
				delete_frame.dispose();
			}
		});
		defaulttablemodel=new DefaultTableModel(null,title);
		table=new JTable(defaulttablemodel);
		sp=new JScrollPane(table);
		add(sp);
		sp.setBounds(100, 160, (getToolkit().getScreenSize().width)-150, 300);
		button3=new JButton("Delete");
		button3.setBounds(600, 520, 100, 20);
		add(button3);
		button3.addActionListener(this);
		c=new JComboBox<String>();
		c.setBounds(400, 100, 120, 20);
		add(c);
		c.setEditable(true);		
		c.getEditor().setItem((String)"");
		PanelAuthorName.s="";		
		((JTextField)c.getEditor().getEditorComponent()).addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent arg0){}
			@Override
			public void keyReleased(KeyEvent arg0){}
			@Override
			public void keyPressed(KeyEvent arg0) {								
				try
				{
					connect_to_db=new Connectivity();
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
				connection=connect_to_db.getConn();				
				try
				{										
					PreparedStatement pstmt=connection.prepareStatement("select * from book where bn like '"+((JTextField)c.getEditor().getEditorComponent()).getText()+arg0.getKeyChar()+"%'");
					ResultSet rs=pstmt.executeQuery();			
					c.removeAllItems();
					ts.clear();
					while(rs.next())
						ts.add(rs.getString("bn"));
					for(String str:ts)
						c.addItem(str);
					((JTextField)c.getEditor().getEditorComponent()).setText(s);
					if((arg0.getKeyChar()>='a' && arg0.getKeyChar()<='z') || (arg0.getKeyChar()>='A' && arg0.getKeyChar()<='Z') || (arg0.getKeyChar()>='0' && arg0.getKeyChar()<='9'))
						s=s+(arg0.getKeyChar());
					if(arg0.getKeyChar()==KeyEvent.VK_BACK_SPACE)
						if(s.length()!=0)
							s=s.substring(0,s.length()-1);
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
		});
	}
	@Override
	public void actionPerformed(ActionEvent a)
	{					
		int f=0;
		if(button2==a.getSource())
		{
			size=0;
			try
			{
				connect_to_db = new Connectivity();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}						
			connection=connect_to_db.getConn();			
			String data[]=new String[6];
			try
			{
				PreparedStatement pstmt=connection.prepareStatement("select * from book where bn = ?");
				pstmt.setString(1,((JTextField)c.getEditor().getEditorComponent()).getText());
				ResultSet rs=pstmt.executeQuery();
				while(rs.next())
				{
					data[0]=String.valueOf(rs.getInt("id"));
					data[1]=rs.getString("bn");
					data[2]=rs.getString("an");
					data[3]=String.valueOf(rs.getInt("sp"));
					data[4]=String.valueOf(rs.getInt("pp"));
					data[5]=String.valueOf(rs.getInt("q"));				
					f=1;
					defaulttablemodel.addRow(data);
				}
			}
			catch(SQLException sqle)
			{	
				sqle.printStackTrace();
			}					
			if(f==0)
			{
				JOptionPane.showMessageDialog(button2, "Book Not Found","ERROR",JOptionPane.ERROR_MESSAGE);				
			}			
			table.addMouseListener(new MouseListener(){
				@Override
				public void mouseReleased(MouseEvent e){}
				@Override
				public void mousePressed(MouseEvent e){}
				@Override
				public void mouseExited(MouseEvent e){}
				@Override
				public void mouseEntered(MouseEvent e){}
				@Override
				public void mouseClicked(MouseEvent e)
				{
					while(!al.isEmpty())
						al.remove(0);
					while(!ll.isEmpty())
						ll.remove(0);
					int a[]=table.getSelectedRows();
					for(int i=0;i<a.length;i++)
					{
						al.add(a[i]);
						ll.add(Integer.parseInt((String)defaulttablemodel.getValueAt(a[i],0)));
					}
				}
			});
		}
		else if(button1==a.getSource())
		{
			c.removeAllItems();
			while(defaulttablemodel.getRowCount()!=0)
				defaulttablemodel.removeRow(0);
			s="";
		}
		else if(button3==a.getSource())
		{
			try
			{
				connect_to_db=new Connectivity();
			}
			catch(IOException ee)
			{
				ee.printStackTrace();
			}
			connection=connect_to_db.getConn();
			PreparedStatement pstmt=null;
			int res=JOptionPane.showConfirmDialog(button1,"Do you want to delete books","Deletion",JOptionPane.YES_NO_OPTION);
			if(res==JOptionPane.YES_OPTION)
			{				
				try
				{	
					int count=0;
					for(int l:al)
					{
						defaulttablemodel.removeRow(l-count);
						count++;
					}
					for(int l:ll)
					{
						pstmt=connection.prepareStatement("delete from book where id=?");
						pstmt.setInt(1,l);
						pstmt.executeUpdate();						
					}
				}
				catch(SQLException ee)
				{
					ee.printStackTrace();
				}				
				JOptionPane.showMessageDialog(button1,"Books Deleted","Info",JOptionPane.INFORMATION_MESSAGE);
			}
		}
	}
}