import java.awt.Font;
import java.awt.event.*;
import java.sql.*;

import javax.swing.*;

public class PanelBookID extends JPanel implements ActionListener,Runnable
{	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton b,b1;
	JTextField t,t1,t2,t3,t4,t5,t6,t7;
	JLabel l1,l2,l3,l4,l5,l6,ll,l,l7;
	JFrame search_frame,menu_frame,pass_frame;	
	int xx;
	String str,str1;
	Thread thread;
	public PanelBookID(final JFrame search_frame,final JFrame menu_frame,final JFrame pass_frame,int x,final String str,final String str1)
	{
		setLayout(null);
		xx=x;
		b=new JButton("Show");
		b.setBounds(720, 100, 100, 20);
		add(b);
		this.search_frame=search_frame;
		this.menu_frame=menu_frame;
		this.pass_frame=pass_frame;
		this.str=str;
		this.str1=str1;
		b.addActionListener(this);
		t=new JTextField();
		t.setBounds(600, 100, 80, 20);
		add(t);
		l1=new JLabel("Enter Book ID");
		l1.setBounds(450, 100, 150, 20);
		add(l1);
		l1=new JLabel("Book ID");
		l1.setBounds(500,200, 150, 20);
		t1=new JTextField();
		t1.setBounds(650,200, 150, 20);
		l2=new JLabel("Book Name");
		l2.setBounds(500,240, 150, 20);
		t2=new JTextField();
		t2.setBounds(650,240, 150, 20);
		l3=new JLabel("Author Name");
		l3.setBounds(500,280, 150, 20);
		t3=new JTextField();
		t3.setBounds(650,280, 150, 20);
		l7=new JLabel("Category");
		l7.setBounds(500,320, 150, 20);
		t7=new JTextField();
		t7.setBounds(650,320, 150, 20);		
		l4=new JLabel("Sale price");
		l4.setBounds(500,360, 150, 20);
		t4=new JTextField();
		t4.setBounds(650,360, 150, 20);
		l5=new JLabel("Purchase Price");
		l5.setBounds(500,400, 150, 20);
		t5=new JTextField();
		t5.setBounds(650,400, 150, 20);
		l6=new JLabel("Quantity");
		l6.setBounds(500,440, 150, 20);
		t6=new JTextField();
		t6.setBounds(650,440, 150, 20);
		b1=new JButton("Clear");		
		ll=new JLabel("");
		ll.setFont(new Font(getName(),Font.ITALIC,20));
		ll.setBounds(600, 440, 300, 40);
		add(ll);
		b1.setBounds(850, 100, 100, 20);
		l=new JLabel(new ImageIcon("back.jpg"));
		l.setBounds(1270, 10, 35, 35);
		add(l);
		thread=new Thread(this);
		setFocusable(true);
		addKeyListener(new KeyListener() {
			@Override
			public void keyTyped(KeyEvent arg0) {}
			@Override
			public void keyReleased(KeyEvent arg0) {}
			@Override
			public void keyPressed(KeyEvent arg0) {
				if(arg0.getKeyChar()==KeyEvent.VK_ESCAPE)
					thread.start();
			}
		});
		l.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent arg0){}
			@Override
			public void mousePressed(MouseEvent arg0){}
			@Override
			public void mouseExited(MouseEvent arg0){}
			@Override
			public void mouseEntered(MouseEvent arg0){}
			@Override
			public void mouseClicked(MouseEvent arg0)
			{
				menu_frame.setVisible(true);
				search_frame.dispose();
			}
		});
		add(l1);add(l2);add(l3);add(l4);add(l5);add(l6);add(t1);add(t2);add(t3);add(t4);add(t5);add(t6);add(b1);add(l7);add(t7);
		b1.addActionListener(this);		
	}
	@Override
	public void actionPerformed(ActionEvent a)
	{			
		Connectivity cc=null;
		Connection con=null;
		int f=0;
		if(b==a.getSource())
		{
			try
			{
				cc = new Connectivity();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}						
			con=cc.getConn();
			try
			{
				PreparedStatement pstmt=con.prepareStatement("select * from book where id=?");
				try{									
					pstmt.setInt(1, Integer.parseInt(t.getText()));
					ResultSet rs=pstmt.executeQuery();
					while(rs.next())
					{
						t1.setText(String.valueOf(rs.getInt("id")));
						t2.setText(rs.getString("bn"));
						t3.setText(rs.getString("an"));
						t4.setText(String.valueOf(rs.getInt("sp")));
						t5.setText(String.valueOf(rs.getInt("pp")));
						t6.setText(String.valueOf(rs.getInt("q")));
						t7.setText(rs.getString("cat"));
						f=1;
						break;
					}
				}
				catch(NumberFormatException e){
					JOptionPane.showMessageDialog(b,"Please Enter a integer value","Error",JOptionPane.ERROR_MESSAGE);
					f=1;
				}
			}
			catch(SQLException sqle)
			{	
				sqle.printStackTrace();
			}
			if(f==0)
				JOptionPane.showMessageDialog(b,"No Book available of this ID","ERROR",JOptionPane.ERROR_MESSAGE);
			setFocusable(true);
		}
		else if(b1==a.getSource())
		{
			t.setText("");
			t1.setText("");
			t2.setText("");
			t3.setText("");
			t4.setText("");
			t5.setText("");
			t6.setText("");
			t7.setText("");
			ll.setText("");
			setFocusable(true);
		}		
	}
	@Override
	public void run() {
		while(thread==Thread.currentThread())
		{
			menu_frame.setVisible(true);
			search_frame.dispose();
		}
	}
}