import java.awt.event.*;
import java.io.IOException;
import java.sql.*;

import javax.swing.*;

public class StudentIssuedBook extends JFrame
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Connectivity connect_to_db;
	Connection connection;
	JFrame current_frame;
	String student_id;
	JTable table;
	Thread thread1,thread2;
	int f;
	public StudentIssuedBook(final JFrame current_frame,String student_id)
	{
		setLayout(null);
		setSize(800,300);
		this.current_frame=current_frame;
		this.student_id=student_id;		
		try{
			connect_to_db=new Connectivity();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		connection=connect_to_db.getConn();
		int size=0;		
		String str2[]={"Book ID","Book Name","Author Name","Price","Book Issued","remainin days","Fine"};		
		int i=0;		
		try{
			PreparedStatement pstmt=connection.prepareStatement("select * from transaction where sid=? and return_date=?");
			pstmt.setString(1,student_id);
			pstmt.setString(2,"");
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				f=1;
				size++;
			}		
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		String str1[][]=new String[size][7];
		try{				
			PreparedStatement pstmt1;
			ResultSet rs1;
			PreparedStatement pstmt=connection.prepareStatement("select book_issued,-DATEDIFF(issued_date,CURDATE())-1 from transaction where sid=? and return_date=?");
			pstmt.setString(1,student_id);
			pstmt.setString(2,"");
			ResultSet rs=pstmt.executeQuery();			
			while(rs.next()){
				pstmt1=connection.prepareStatement("select * from book where id=?");
				pstmt1.setString(1,rs.getString(1));
				rs1=pstmt1.executeQuery();					
				while(rs1.next()){
					str1[i][0]=String.valueOf(rs1.getInt("id"));
					str1[i][1]=rs1.getString("bn");
					str1[i][2]=rs1.getString("an");
					str1[i][3]=(String.valueOf(rs1.getInt("sp")));
					str1[i][4]=(String.valueOf(rs.getInt(1)));
					System.out.println(rs.getInt(2));
					if(rs.getInt(2)>=15)
						str1[i][5]=String.valueOf(0);
					else
						str1[i][5]=(String.valueOf(15-rs.getInt(2)));
					if(rs.getInt(2)>15)
						str1[i][6]=String.valueOf(rs.getInt("book_issued")*rs.getInt(2));
					else
						str1[i][6]=String.valueOf(0);
				}
				i++;
			}			
		}			
		catch(SQLException e){
			e.printStackTrace();
		}
		table=new JTable(str1,str2);
		JScrollPane sp=new JScrollPane(table);
		add(sp);
		sp.setBounds(100,50,600,100);	
		addWindowListener(new WindowAdapter() { public void windowClosing(WindowEvent we){
			dispose(); current_frame.setVisible(true);
		} });					
	}	
}