import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import java.io.IOException;
import java.sql.*;

import javax.swing.*;

public class ChangePassword extends JFrame implements ActionListener,Runnable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel label1,label2,label3,label4,label5,label6;
	JPasswordField passfield1,passfield2,passfield3;
	JButton button1,button2;
	ImageIcon icon1,icon2;
	int xx;
	Thread thread;
	JFrame current_frame;
	String id;
	public ChangePassword(JFrame obj,int x,String id)
	{
		setSize(400,350);
		setLayout(null);
		this.id=id;
		xx=x;
		current_frame=obj;
		setLocationRelativeTo(this);
		current_frame.setEnabled(false);
		if(xx==1)
			label1=new JLabel("Change Password for admin");
		else
			label1=new JLabel("Change Password for student");			
		label1.setFont(new Font(getName(), Font.ITALIC, 20));
		label1.setBounds(20, 40, 300, 30);
		add(label1);
		label2=new JLabel("Current Password");
		label2.setBounds(60, 100, 120, 20);
		add(label2);
		passfield1=new JPasswordField("");
		passfield1.setBounds(200, 100, 120, 20);
		add(passfield1);
		label3=new JLabel("New Password");
		label3.setBounds(60, 140, 120, 20);
		add(label3);
		icon1=new ImageIcon("wrong.png");
		icon2=new ImageIcon("correct.png");
		passfield2=new JPasswordField("");
		passfield2.setBounds(200, 140, 120, 20);
		add(passfield2);
		label5=new JLabel();
		label5.setBounds(200, 165, 200, 20);
		add(label5);
//		System.out.println(id);
		label4=new JLabel("Confirm Password");
		label4.setBounds(60, 200, 120, 20);
		add(label4);
		passfield3=new JPasswordField("");
		passfield3.setBounds(200, 200, 120, 20);
		add(passfield3);
		label6=new JLabel();		
		label6.setBounds(335, 182, 50, 50);
		add(label6);
		button1=new JButton("Change");
		button1.setBounds(75, 270, 100, 20);
		add(button1);
		button2=new JButton("Cancel");
		button2.setBounds(195, 270, 100, 20);
		add(button2);
		button1.addActionListener(this);
		button2.addActionListener(this);
		thread=new Thread(this);
		thread.start();
		addWindowListener(new WindowAdapter() { public void windowClosing(WindowEvent e){ current_frame.setEnabled(true); dispose(); } });		
	}
	@SuppressWarnings("deprecation")
	@Override
	public void actionPerformed(ActionEvent a)
	{
		Connectivity cc=null;
		Connection con=null;
		int f=0;
		int fa=0,fn=0,fs=0;		
		if(button1==a.getSource())
		{
			try
			{
				cc=new Connectivity();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
			con=cc.getConn();
			if(xx==1)
			{
				try{
					PreparedStatement pstmt=con.prepareStatement("select * from librarien where un=? and pass=?");
					pstmt.setString(1, id);
					pstmt.setString(2, passfield1.getText());
					ResultSet rs=pstmt.executeQuery();
					while(rs.next())
						f=1;
				}
				catch(SQLException e){
					e.printStackTrace();
				}
				if(f==1)
				{
					if(passfield2.getText().equals(passfield3.getText()))
					{
						try
						{
							PreparedStatement pstmt1=con.prepareStatement("update librarien set pass=? where un=? and pass=?");
							PreparedStatement pstmt2=con.prepareStatement("update backup_librarien set pass=? where un=? and pass=?");
							PreparedStatement pstmt3=con.prepareStatement("delete from session where un=? and pass=?");
							pstmt1.setString(1, passfield2.getText());
							pstmt1.setString(2, id);
							pstmt1.setString(3, passfield1.getText());
							pstmt2.setString(1, passfield2.getText());
							pstmt2.setString(2, id);
							pstmt2.setString(3, passfield1.getText());
							pstmt3.setString(1, id);
							pstmt3.setString(2, passfield1.getText());
							if(passfield2.getText().length()>8 && passfield2.getText().length()<20)
							{
								for(int i=0;i<passfield2.getText().length();i++)
								{
									if(passfield2.getText().charAt(i)>'A' && passfield2.getText().charAt(i)<'Z')
									{
										fa=1;
										continue;
									}
									if(passfield2.getText().charAt(i)>'0' && passfield2.getText().charAt(i)<'9')
									{
										fn=1;
										continue;
									}
									if(!(passfield2.getText().charAt(i)>'0' && passfield2.getText().charAt(i)<'9') && !(passfield2.getText().charAt(i)>'A' && passfield2.getText().charAt(i)<'Z') && !(passfield2.getText().charAt(i)>'a' && passfield2.getText().charAt(i)<'z'))
									{
										fs=1;
										continue;
									}
								}
							}
							if((fa==1) && (fn==1) && (fs==1))
							{
								dispose();
								int res=JOptionPane.showConfirmDialog(button1,"Do you want to Change Password","Change Password",JOptionPane.YES_NO_OPTION);
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");
								if(res==JOptionPane.YES_OPTION)
								{						
									pstmt1.executeUpdate();
									pstmt2.executeUpdate();
									pstmt3.executeUpdate();
									current_frame.setEnabled(true);
									dispose();									
								}								
							}
							else if((fa==1) && (fn==1) && (fs==0))
							{
								JOptionPane.showMessageDialog(button1,"There should be atleast 1 Symbol");
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");								
							}
							else if((fa==1) && (fn==0) && (fs==1))
							{
								JOptionPane.showMessageDialog(button1,"There should be atleast 1 Numeric");
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");
							}
							else if((fa==0) && (fn==1) && (fs==1))
							{
								JOptionPane.showMessageDialog(button1,"There should be atleast 1 Upper case");
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");
							}
							else if((fa==1) && (fn==0) && (fs==0))
							{
								JOptionPane.showMessageDialog(button1,"There should be atleast 1 Symbol & Numeric");
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");
							}
							else if((fa==0) && (fn==1) && (fs==0))
							{
								JOptionPane.showMessageDialog(button1,"There should be atleast 1 Symbol & Upper case");
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");
							}
							else if((fa==0) && (fn==0) && (fs==1))
							{
								JOptionPane.showMessageDialog(button1,"There should be atleast 1 Upper case & Numeric");
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");
							}
							else if((fa==0) && (fn==0) && (fs==0))
							{
								JOptionPane.showMessageDialog(button1,"There should be atleast 1 Symbol,Numeric,Upper case");
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");
							}
						}
						catch(SQLException e)
						{
							JOptionPane.showMessageDialog(button1, "This username and password is already exist");
						}
					}
					else
					{
						JOptionPane.showMessageDialog(button1, "New password confirmation is incorrect");
					}
				}
				else
				{
					JOptionPane.showMessageDialog(button1,"Current Password Incorrect","Wrong password",JOptionPane.ERROR_MESSAGE);
					passfield1.setText("");
					passfield2.setText("");
					passfield3.setText("");
					label6.setBounds(335,182,0,0);
					label5.setText("");
				}
			}
			else if(xx==2)
			{
				try
				{
					PreparedStatement pstmt=con.prepareStatement("select * from student where id=? and pass=?");					
					pstmt.setString(1, id);
					pstmt.setString(2, passfield1.getText());
					ResultSet rs=pstmt.executeQuery();
					while(rs.next())
					{
						f=1;
					}
				}
				catch(SQLException e)
				{
					e.printStackTrace();
				}
				if(f==1)
				{
					if(passfield2.getText().equals(passfield3.getText()))
					{
						try
						{
							PreparedStatement pstmt1=con.prepareStatement("update student set pass=? where id=? and pass=?");
							PreparedStatement pstmt2=con.prepareStatement("update backup_student set pass=? where id=? and pass=?");
							pstmt1.setString(1, passfield2.getText());
							pstmt1.setString(2, id);
							pstmt1.setString(3, passfield1.getText());
							pstmt2.setString(1, passfield2.getText());
							pstmt2.setString(2, id);
							pstmt2.setString(3, passfield1.getText());
							if(passfield2.getText().length()>8 && passfield2.getText().length()<20)
							{
								for(int i=0;i<passfield2.getText().length();i++)
								{
									if(passfield2.getText().charAt(i)>'A' && passfield2.getText().charAt(i)<'Z')
									{
										fa=1;
										continue;
									}
									if(passfield2.getText().charAt(i)>'0' && passfield2.getText().charAt(i)<'9')
									{
										fn=1;
										continue;
									}
									if(!(passfield2.getText().charAt(i)>'0' && passfield2.getText().charAt(i)<'9') && !(passfield2.getText().charAt(i)>'A' && passfield2.getText().charAt(i)<'Z') && !(passfield2.getText().charAt(i)>'a' && passfield2.getText().charAt(i)<'z'))
									{
										fs=1;
										continue;
									}
								}
							}
							if((fa==1) && (fn==1) && (fs==1))
							{
								dispose();
								int res=JOptionPane.showConfirmDialog(button1,"Do you want to Change Password","Change Password",JOptionPane.YES_NO_OPTION);
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");
								current_frame.setEnabled(true);
								if(res==JOptionPane.YES_OPTION)
								{						
									pstmt1.executeUpdate();
									pstmt2.executeUpdate();
									dispose();									
								}								
							}
							else if((fa==1) && (fn==1) && (fs==0))
							{
								JOptionPane.showMessageDialog(button1,"There should be atleast 1 Symbol");
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");								
							}
							else if((fa==1) && (fn==0) && (fs==1))
							{
								JOptionPane.showMessageDialog(button1,"There should be atleast 1 Numeric");
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");
							}
							else if((fa==0) && (fn==1) && (fs==1))
							{
								JOptionPane.showMessageDialog(button1,"There should be atleast 1 Upper case");
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");
							}
							else if((fa==1) && (fn==0) && (fs==0))
							{
								JOptionPane.showMessageDialog(button1,"There should be atleast 1 Symbol & Numeric");
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");
							}
							else if((fa==0) && (fn==1) && (fs==0))
							{
								JOptionPane.showMessageDialog(button1,"There should be atleast 1 Symbol & Upper case");
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");
							}
							else if((fa==0) && (fn==0) && (fs==1))
							{
								JOptionPane.showMessageDialog(button1,"There should be atleast 1 Upper case & Numeric");
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");
							}
							else if((fa==0) && (fn==0) && (fs==0))
							{
								JOptionPane.showMessageDialog(button1,"There should be atleast 1 Symbol,Numeric,Upper case");
								passfield1.setText("");
								passfield2.setText("");
								passfield3.setText("");
							}
						}
						catch(SQLException e)
						{
							JOptionPane.showMessageDialog(button1, "This username and password is already exist");
						}
					}
					else
					{
						JOptionPane.showMessageDialog(button1, "New password confirmation is incorrect");
					}
				}
				else if(f==0)
				{
					JOptionPane.showMessageDialog(button1,"Current Password Incorrect","Password wrong",JOptionPane.ERROR_MESSAGE);
					passfield1.setText("");
					passfield2.setText("");
					passfield3.setText("");					
					label6.setBounds(335,182,0,0);
					label5.setText("");
				}
			}			
		}
		else if(button2==a.getSource())
		{
			passfield1.setText("");
			passfield2.setText("");
			passfield3.setText("");
			current_frame.setEnabled(true);
			dispose();
		}		
	}
	@SuppressWarnings("deprecation")
	@Override
	public void run() {
		while(thread==Thread.currentThread())
		{
			if(passfield3.getText().length()!=0)
			{
				label6.setBounds(335,182,50,50);
				if(passfield3.getText().equals(passfield2.getText()))
					label6.setIcon(icon2);
				else
					label6.setIcon(icon1);				
			}
			if(passfield3.getText().length()<1)
				label6.setBounds(335,182,0,0);
			if(passfield2.getText().equals(""))
				label5.setText("");
			else if(passfield2.getText().length()<=12)
			{
				label5.setText("Weak Password");
				label5.setForeground(Color.pink);
			}
			else if(passfield2.getText().length()<=24)
			{
				label5.setText("Medium Password");
				label5.setForeground(Color.yellow);
			}
			else if(passfield2.getText().length()<=32)
			{
				label5.setText("Strong Password");
				label5.setForeground(Color.green);
			}
			else
			{
				JOptionPane.showMessageDialog(this,"Limit Exceed","",JOptionPane.ERROR_MESSAGE);				
				passfield2.setText("");				
			}
		}					
	}	
}