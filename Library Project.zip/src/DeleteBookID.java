import java.awt.Font;
import java.awt.event.*;
import java.sql.*;

import javax.swing.*;

public class DeleteBookID extends JPanel implements ActionListener
{	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton b,b1;
	JTextField t,t1,t2,t3,t4,t5,t6;
	JLabel l1,l2,l3,l4,l5,l6,ll,l0,lb;
	JFrame delete_frame,menu_frame;
	String str,str1;
	public DeleteBookID(final JFrame delete_frame,final JFrame menu_frame,String str,String str1)
	{
		setLayout(null);
		b=new JButton("Delete");
		b.setBounds(720, 100, 100, 20);
		add(b);
		this.delete_frame=delete_frame;
		this.menu_frame=menu_frame;
		this.str=str;
		this.str1=str1;
		b.addActionListener(this);
		t=new JTextField();
		t.setBounds(600, 100, 80, 20);
		add(t);
		ll=new JLabel("Enter Book ID");
		ll.setBounds(450, 100, 150, 20);
		add(ll);
		l1=new JLabel("Book ID");
		l1.setBounds(550,150, 150, 20);
		t1=new JTextField();
		t1.setBounds(650,150, 150, 20);
		l2=new JLabel("Book Name");
		l2.setBounds(550,190, 150, 20);
		t2=new JTextField();
		t2.setBounds(650,190, 150, 20);
		l3=new JLabel("Author Name");
		l3.setBounds(550, 230, 150, 20);
		t3=new JTextField();
		t3.setBounds(650, 230, 150, 20);
		l4=new JLabel("Sale price");
		l4.setBounds(550, 270, 150, 20);
		t4=new JTextField();
		t4.setBounds(650, 270, 150, 20);
		l5=new JLabel("Purchase Price");
		l5.setBounds(550, 310, 150, 20);
		t5=new JTextField();
		t5.setBounds(650, 310, 150, 20);
		l6=new JLabel("Quantity");
		l6.setBounds(550, 350, 150, 20);
		t6=new JTextField();
		t6.setBounds(650, 350, 150, 20);
		b1=new JButton("Clear");
		lb=new JLabel(new ImageIcon("back.jpg"));
		lb.setBounds(getToolkit().getScreenSize().width-80,10,50,50);
		add(lb);
		lb.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent arg0) {}
			@Override
			public void mousePressed(MouseEvent arg0) {}
			@Override
			public void mouseExited(MouseEvent arg0) {}
			@Override
			public void mouseEntered(MouseEvent arg0) {}
			@Override
			public void mouseClicked(MouseEvent arg0) {
				menu_frame.setVisible(true);
				delete_frame.dispose();
			}
		});
		b1.setBounds(550, 520, 100, 20);		
		add(l1);add(l2);add(l3);add(l4);
		add(l5);add(l6);add(t1);add(t2);
		add(t3);add(t4);add(t5);add(t6);
		add(b1);
		b1.addActionListener(this);		
		ll=new JLabel("");
		ll.setFont(new Font(getName(),Font.ITALIC,20));
		ll.setBounds(600, 440, 300, 40);
		add(ll);
	}
	@Override
	public void actionPerformed(ActionEvent a)
	{
		Connectivity cc=null;
		Connection con=null;
		int f=0;
		if(b==a.getSource())
		{
			try
			{
				cc = new Connectivity();
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}						
			con=cc.getConn();
			try
			{
				PreparedStatement pstmt=con.prepareStatement("select * from book where id=?");
				pstmt.setInt(1,Integer.parseInt(t.getText()));
				ResultSet rs=pstmt.executeQuery();
				while(rs.next())
				{
					t1.setText(rs.getString("id"));
					t2.setText(rs.getString("bn"));
					t3.setText(rs.getString("an"));
					t4.setText(String.valueOf(rs.getInt("sp")));
					t5.setText(String.valueOf(rs.getInt("pp")));
					t6.setText(String.valueOf(rs.getInt("q")));
					f=1;
					break;
				}
			}
			catch(SQLException sqle)
			{	
				sqle.printStackTrace();
			}
			if(f==0)
				JOptionPane.showMessageDialog(this,"No Books available","ERROR",JOptionPane.ERROR_MESSAGE);
			else
			{
				try
				{
					PreparedStatement pstmt=con.prepareStatement("delete from book where id=?");
					pstmt.setInt(1,Integer.parseInt(t.getText()));
					int result=JOptionPane.showConfirmDialog(b,"Do you want to delete it","Delete Book",JOptionPane.YES_NO_OPTION);
					if(result==JOptionPane.YES_OPTION)
					{
						int y=pstmt.executeUpdate();						
						JOptionPane.showConfirmDialog(null,y+" Records Deleted","Message",JOptionPane.PLAIN_MESSAGE);
						t.setText("");
						t1.setText("");
						t2.setText("");
						t3.setText("");
						t4.setText("");
						t5.setText("");
						t6.setText("");
					}
				}
				catch(SQLException sqle)
				{	
					sqle.printStackTrace();
				}
			}
		}
		if(b1==a.getSource())
		{
			t.setText("");
			t1.setText("");
			t2.setText("");
			t3.setText("");
			t4.setText("");
			t5.setText("");
			t6.setText("");
			ll.setText("");
		}		
	}
}