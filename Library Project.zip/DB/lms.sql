/*
SQLyog Enterprise - MySQL GUI v7.02 
MySQL - 5.0.67-community-nt : Database - lms
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`lms` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `lms`;

/*Table structure for table `backup_librarien` */

DROP TABLE IF EXISTS `backup_librarien`;

CREATE TABLE `backup_librarien` (
  `name` varchar(50) NOT NULL,
  `add` varchar(50) NOT NULL,
  `pn` varchar(15) NOT NULL,
  `un` varchar(20) NOT NULL,
  `pass` varchar(32) NOT NULL,
  `qus` varchar(50) NOT NULL,
  `ans` varchar(20) NOT NULL,
  PRIMARY KEY  (`un`,`pass`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `backup_librarien` */

insert  into `backup_librarien`(`name`,`add`,`pn`,`un`,`pass`,`qus`,`ans`) values ('Paras jain','PIET, sitapura, Jaipur','9636103349','parasrock','PARAS@9636','What is your favourite Movie','300'),('Paras Jain','Jaipur','9636103349','paras_jain','ROCK@9636','What is your favourite Movie','300'),('Shiv Raghav','PIET','1234567890','shibburock','MYGOD@2230','What is your favourite Movie','300');

/*Table structure for table `backup_student` */

DROP TABLE IF EXISTS `backup_student`;

CREATE TABLE `backup_student` (
  `id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `section` varchar(10) NOT NULL,
  `branch` varchar(10) NOT NULL,
  `pn` varchar(15) default NULL,
  `pass` varchar(32) NOT NULL,
  `qus` varchar(50) NOT NULL,
  `ans` varchar(20) NOT NULL,
  `add` varchar(40) NOT NULL,
  `ib` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `backup_student` */

insert  into `backup_student`(`id`,`name`,`section`,`branch`,`pn`,`pass`,`qus`,`ans`,`add`,`ib`) values ('pce/2ce/11/041','Avinash kumar','C','CS','9649425745','AVINASH@9636','What is your NickName','Pratap nagar','kejriwal',0),('pce/2ce/11/046','Paras Jain','C','CS','9636103349','PARAS@9636','What is your favourite Movie','300','PIET',0);

/*Table structure for table `book` */

DROP TABLE IF EXISTS `book`;

CREATE TABLE `book` (
  `id` int(11) NOT NULL auto_increment,
  `bn` varchar(100) NOT NULL,
  `an` varchar(100) NOT NULL,
  `sp` int(11) NOT NULL,
  `pp` int(11) default NULL,
  `q` int(11) NOT NULL,
  `cat` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `book` */

insert  into `book`(`id`,`bn`,`an`,`sp`,`pp`,`q`,`cat`) values (1,'jbjv','bjvhgv',100,80,100,'hhjghvgv'),(2,'bhvhgv','bhbhjbj',200,180,8,'bvghv'),(3,'jvgv','gvhgvbjnj',300,270,6,'njhbj');

/*Table structure for table `librarien` */

DROP TABLE IF EXISTS `librarien`;

CREATE TABLE `librarien` (
  `name` varchar(50) NOT NULL,
  `add` varchar(50) NOT NULL,
  `pn` varchar(15) NOT NULL,
  `un` varchar(20) NOT NULL,
  `pass` varchar(32) NOT NULL,
  `qus` varchar(50) NOT NULL,
  `ans` varchar(20) NOT NULL,
  PRIMARY KEY  (`un`,`pass`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `librarien` */

insert  into `librarien`(`name`,`add`,`pn`,`un`,`pass`,`qus`,`ans`) values ('Paras jain','Pratap Nagar, Jaipur','9636103349','parasrock','PARAS@9636','What is your favourite Movie','300'),('Paras Jain','Jaipur','9636103349','paras_jain','ROCK@9636','What is your favourite Movie','300'),('Shiv Raghav','PIET','1234567890','shibburock','MYGOD@2230','What is your favourite Movie','300');

/*Table structure for table `session` */

DROP TABLE IF EXISTS `session`;

CREATE TABLE `session` (
  `id` varchar(20) NOT NULL,
  `pass` varchar(32) NOT NULL,
  `ip` varchar(20) NOT NULL,
  PRIMARY KEY  (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `session` */

insert  into `session`(`id`,`pass`,`ip`) values ('parasrock','ROCK@9636','127.0.0.1');

/*Table structure for table `student` */

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `section` varchar(10) NOT NULL,
  `branch` varchar(10) NOT NULL,
  `pn` varchar(15) default NULL,
  `pass` varchar(32) NOT NULL,
  `qus` varchar(50) NOT NULL,
  `ans` varchar(20) NOT NULL,
  `add` varchar(40) NOT NULL,
  `ib` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `student` */

insert  into `student`(`id`,`name`,`section`,`branch`,`pn`,`pass`,`qus`,`ans`,`add`,`ib`) values ('pce/2ce/11/041','Avinash kumar','C','CS','9649425745','AVINASH@9636','What is your NickName','kejriwal','Pratap nagar',0),('pce/2ce/11/046','Paras Jain','C','CS','9636103349','PARAS@9636','What is your favourite Movie','300','PIET, Jaipur',0);

/*Table structure for table `transaction` */

DROP TABLE IF EXISTS `transaction`;

CREATE TABLE `transaction` (
  `bid` int(11) NOT NULL,
  `sid` varchar(20) NOT NULL,
  `book_issued` int(11) NOT NULL,
  `issued_date` varchar(20) NOT NULL,
  `issued_time` varchar(20) NOT NULL,
  `return_date` varchar(20) default NULL,
  PRIMARY KEY  (`bid`,`sid`,`issued_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `transaction` */

insert  into `transaction`(`bid`,`sid`,`book_issued`,`issued_date`,`issued_time`,`return_date`) values (1,'pce/2ce/11/046',1,'2014-03-05','11:26:47','2014-04-05');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
